# Module:      VmWareTfsIntegration.PS1
#
# Source:      www.havecomputerwillcode.com/blog
#
# Author:      Graham Stephenson
# Date:        18-March-2011
#
# NOTES:       Before running this, install the latest VIX and add VMRUN.EXE to your path. 
#              There is NO Error Checking in this. Good luck!
#
# Disclaimer:  DO NOT USE THIS CODE UNDER ANY CIRCUMSTANCES WHATSOEVER (that should just about cover it!)
#

# VmWare Authentication Parameters. See VmRun.EXE for more information. 
#
$VmWareHostType = "server";         # VmWare Server 2.0 (replace with "ws" if Workstation)
$VmWareHostName = "localhost";      # Only needed for VmWare Server. Ignored by Workstation. 
$VmWareHostPort = "8333";			# Only needed for VmWare Server. Ignored by Workstation. 
$VmWareUsername = "Administrator";  # Only needed for VmWare Server. Ignored by Workstation. 
$VmWarePassword = "whatever";      # Only needed for VmWare Server. Ignored by Workstation. 

$VmWareGuestUsername = "Graham";    # Administrator user name you would log in as interactively. 
$VmWareGuestPassword = "moo";       # Password for Administrator account. 

# Parameters required for joining a domain
#
$DomainUsername = "Administrator";
$DomainPassword = "whatever";
$DomainName = "WOOHOO.COM";

# The new machine name
$MachineName = "Moo1410";

# The share location on the domain network which contains an 'Agents', 'ResponseFiles' and 'Patches' directory. 
$VisualStudioGumpfUnc = "\\10.0.0.1\VisualStudioGumpf";
 
# Test Controller Parameters
$TestControllerTfsTeamProjectCollection = "http://WIN-TSKURFCLU7G.WOOHOO.COM:8080/Tfs/DefaultCollection";
$TestControllerTfsServiceUser = "WOOHOO.COM\TfsTest";
$TestControllerTfsServicePassword = "whatever";

# Test Agent Parameters
# I want to log in the user automatically so I can do UI Testing: these are the credentials under which the Test will be run. 
$TestProcessUsername = "Graham";
$TestProcessPassword = "moo";
# The Test Agent needs to know what Test Controller to connect to. As we only have one machine, use localhost.
$TestControllerUri = "localhost:6901";

# The Team Project Name we want to register the environment with and the environment name
$TeamProjectName = "TestSample";
$EnvironmentName = "My 1410 Environment";
$MachineRole = "Web Server";

# Get this string from using the VMRUN.EXE listRegisteredVM Command to find out the location of the Virtual Machines 
$VmWareGoldenImageSourceLocation = "[VmWareImages] Golden XP Pro Service Pack 3/Golden XP Pro Service Pack 3.vmx";
# This is the name of 'VmWareGoldenImageSourceName' after it has been cloned. Not used for VmWare Server (VMRUN.EXE not supported) so just pass in any value. 
# Probably makes sense to format use the Time to make the folder unique... 
$VmWareGoldenImageTargetLocation = "[VmWareImages] The New Directory/Golden XP Pro Service Pack 3.vmx"; 

# ---------------------------------------------------------------------------------------------------------------------
# - Everything below here is script 
# ---------------------------------------------------------------------------------------------------------------------

# Work out what the target VMX Filename is (Target location of Workstation; original source (after revert) for VmWare Server). 
if($VmWareHostType -eq "ws")
{
	$VmWareClonedImageLocation = $VmWareGoldenImageTargetLocation;
}
elseif($VmWareHostType -eq "server")
{
	$VmWareClonedImageLocation = $VmWareGoldenImageSourceLocation;
}

# As all calls to VmRun.EXE require the connection parameters, dump them all in a dictionary for common usage.
$VmWareConnectionParameters = @{ "VmWareHostType" = $VmWareHostType; "VmWareHostName" = $VmWareHostName; "VmWareHostPort" = $VmWareHostPort; "VmWareUsername" = $VmWareUsername; "VmWarePassword" = $VmWarePassword }
  
.\Scripts\Helpers.ps1

# ListVirtualMachines $VmWareConnectionParameters

# STAGE 2: Provision a new Virtual Machine and join it to a domain
CloneVirtualMachine $VmWareConnectionParameters $VmWareGoldenImageSourceLocation $VmWareGoldenImageTargetLocation;

StartVirtualMachine $VmWareConnectionParameters $VmWareClonedImageLocation $VmWareGuestUsername $VmWareGuestPassword;

RenameVirtualMachine  $VmWareConnectionParameters $VmWareClonedImageLocation $VmWareGuestUsername $VmWareGuestPassword $MachineName;
StopVirtualMachine $VmWareConnectionParameters $VmWareClonedImageLocation $VmWareGuestUsername $VmWareGuestPassword;

StartVirtualMachine $VmWareConnectionParameters $VmWareClonedImageLocation $VmWareGuestUsername $VmWareGuestPassword;
JoinVirtualMachineToDomain $VmWareConnectionParameters $VmWareClonedImageLocation $VmWareGuestUsername $VmWareGuestPassword $DomainUsername $DomainPassword $DomainName;
StopVirtualMachine $VmWareConnectionParameters $VmWareClonedImageLocation $VmWareGuestUsername $VmWareGuestPassword;

# STAGE 3: Automate the installation of the Test Controller and Agent. 
# We pass in the Domain Username and Domain Password for the machine now because we want to install the Test Controller using a Domain Account that has access to the VisualStudioGumpf share. 
StartVirtualMachine $VmWareConnectionParameters $VmWareClonedImageLocation $VmWareGuestUsername $VmWareGuestPassword;

InstallTestController $VmWareConnectionParameters $VmWareClonedImageLocation "$DomainName\$DomainUsername" $DomainPassword $VisualStudioGumpfUnc;
InstallTestAgent $VmWareConnectionParameters $VmWareClonedImageLocation "$DomainName\$DomainUsername" $DomainPassword $VisualStudioGumpfUnc;
# If you want to install the KB Patch, run this :-) Check that the InstallTestPatches.BAT file is installing the correct Platform for your Virtual Machine (32-bit vs 64-bit)
InstallTestPatches $VmWareConnectionParameters $VmWareClonedImageLocation "$DomainName\$DomainUsername" $DomainPassword $VisualStudioGumpfUnc;

# STAGE 4: Configure Test Controller + Test Agent
ConfigureTestController $VmWareConnectionParameters $VmWareClonedImageLocation "$DomainName\$DomainUsername" $DomainPassword $TestControllerTfsTeamProjectCollection $TestControllerTfsServiceUser $TestControllerTfsServicePassword
ConfigureTestAgent $VmWareConnectionParameters $VmWareClonedImageLocation "$DomainName\$DomainUsername" $DomainPassword $TestProcessUsername $TestProcessPassword $TestControllerUri
StopVirtualMachine $VmWareConnectionParameters $VmWareClonedImageLocation $VmWareGuestUsername $VmWareGuestPassword;

StartVirtualMachine $VmWareConnectionParameters $VmWareClonedImageLocation $VmWareGuestUsername $VmWareGuestPassword;

# STAGE 5: Create the Environment
# It can take a while for the VM to spin up and the Test Controller + Test Agent to come online... so use the RETRYCOUNT here.
Invoke-Expression "$VisualStudioGumpfUnc\AgentInteraction\AgentInteraction.EXE command=RegisterEnvironment testcontrolleruri=$($MachineName).$($DomainName):6901 TeamProjectName=`"$TeamProjectName`" EnvironmentName=`"$EnvironmentName`" Agents=`"$MachineName,$MachineRole`" RetryCount=10";
