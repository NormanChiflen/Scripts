﻿// Module:      AgentHelpers
//
// Author:      Graham Stephenson (www.havecomputerwillcode.com/blog)
//
// Purpose:     Provide a way of automating the construction of Physical Environments containing Test Controllers and Test Agents with Roles.
//
// Disclaimer:  Do not use under any circumstances! (That should just about cover it!)
//
// NOTES:       Reuse this code wherever you like, but please credit the original author and link to the blog. Cheers!
//

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AgentHelpers
{
    /// <summary>
    /// The list displayed to the user. 
    /// </summary>
    public class TestAgentCandidate
    {
        /// <summary>
        /// Agent Name.
        /// </summary>
        public string AgentName
        {
            get;
            set;
        }

        /// <summary>
        /// Whether to include this in the environment. 
        /// </summary>
        public bool IncludeInEnvironment
        {
            get;
            set;
        }

        /// <summary>
        /// Role name of the parent machine. 
        /// </summary>
        public string ParentMachineRoleName
        {
            get;
            set;
        }
    }
}
