﻿// Module:      AgentHelpers
//
// Author:      Graham Stephenson (www.havecomputerwillcode.com)
//
// Date:        18-March-2011
//
// Disclaimer:  Do not use this code under any circumstances! (That should just about cover it!)
//
// Description: There is no supported Test Controller / Test Agent API at the moment which means (as far as I know) there is no way of programmatically
//              creating a Physical Environment in Lab Center and setting up the Test Controller / Test Agent hierarchy. 
//
//              This class contains a few helper methods that will let you do that. However, they use UNDOCUMENTED API's which means I set up a few structures
//              and just 'jump in' to the code and hope for the best :-) If you use this code and ignore the disclaimer, I strongly recommend you back up
//              your TFS first and check that this works. I make no guarantees!
//
// NOTES:       Reuse this code wherever you like, but please credit the original author and link to the blog. Cheers!
// 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.TeamFoundation.TestManagement.Client;
using Microsoft.TeamFoundation.Client;
using PhysicalEnvironments;

namespace AgentHelpers
{
    public static class Helpers
    {
        /// <summary>
        /// Full path of whether the important DLL resides. 
        /// </summary>
        //public static string ControllerAssemblyPath = @"C:\Windows\assembly\GAC_MSIL\Microsoft.VisualStudio.QualityTools.ControllerObject\10.0.0.0__b03f5f7f11d50a3a\Microsoft.VisualStudio.QualityTools.ControllerObject.dll";
        public static string ControllerAssemblyPath
        {
            get
            {
                string directoryName = System.IO.Path.GetDirectoryName(typeof(Helpers).Assembly.Location);

                string result = String.Format(@"{0}\{1}", directoryName, "Microsoft.VisualStudio.QualityTools.ControllerObject.dll");

                return result;
            }
        }

        /// <summary>
        /// Contains Test Environment objects etc. 
        /// </summary>
        // public static string ControllerExecutionCommonAssemblyPath = @"C:\Windows\assembly\GAC_MSIL\Microsoft.VisualStudio.QualityTools.ExecutionCommon\10.0.0.0__b03f5f7f11d50a3a\Microsoft.VisualStudio.QualityTools.ExecutionCommon.dll";
        public static string ControllerExecutionCommonAssemblyPath
        {
            get
            {
                string directoryName = System.IO.Path.GetDirectoryName(typeof(Helpers).Assembly.Location);

                string result = String.Format(@"{0}\{1}", directoryName, "Microsoft.VisualStudio.QualityTools.ExecutionCommon.dll");

                return result;
            }
        }

        /// <summary>
        /// Type name of the Controller so we can get at the Agents. 
        /// </summary>
        public static string controllerConnectionManagerTypeName = "Microsoft.VisualStudio.TestTools.Controller.ControllerConnectionManager";

        /// <summary>
        /// Type name of the Controller so we can get at the Agents. 
        /// </summary>
        public static string controllerTestEnvironmentTypeName = "Microsoft.VisualStudio.TestTools.Execution.TestEnvironment.TestEnvironment";

        /// <summary>
        /// Type name of the MachineRole. 
        /// </summary>
        public static string controllerMachineRoleTypeName = "Microsoft.VisualStudio.TestTools.Execution.TestEnvironment.MachineRole";



        /// <summary>
        /// List all test controllers registered with this Project Collection.
        /// </summary>
        public static IEnumerable<ITestController> EnumerateTestControllers(TfsTeamProjectCollection collection)
        {
            if (null == collection) throw new System.ArgumentNullException("collection");

            Microsoft.TeamFoundation.TestManagement.Client.TestManagementService service = new Microsoft.TeamFoundation.TestManagement.Client.TestManagementService();
            service.Initialize(collection);
            return service.TestControllers.Query();
        }



        /// <summary>
        /// Get all Agents registered with a test controller.
        /// </summary>
        /// <param name="controllerUri">The controller. Typically of the form: THEMACHINE.THEDOMAIN.COM:6901</param>
        public static IEnumerable<TestAgentInfo> GetAllAgents(string controllerUri)
        {
            List<TestAgentInfo> result = new List<TestAgentInfo>();

            // We have to use undocument API's to do this and be rather creative on how we get the information! 

            // 1. Load the Assembly (or you could locate it in the current AppDomain if it is already loaded). 
            // 2. Connect to the remote Test Controller.
            // 3. Get all of the Test Agents that are registered with it. 

            // 1.
            System.Reflection.Assembly controllerAssembly = System.Reflection.Assembly.LoadFile(ControllerAssemblyPath);

            // 2.
            Type controllerConnectionManagerType = controllerAssembly.GetType(controllerConnectionManagerTypeName);

            object controllerConnectionManager = controllerConnectionManagerType.InvokeMember("Connect", System.Reflection.BindingFlags.InvokeMethod, null, controllerConnectionManagerType, new object[] { controllerUri });
            dynamic controllerConnectionManagerWrapper = new AccessPrivateWrapper(controllerConnectionManager);

            // 3.
            // What we actually get back here is an AgentProperties object saying whether each Agent is Online etc. 
            dynamic agents = controllerConnectionManagerWrapper.GetAllAgents();

            foreach (dynamic agent in agents)
            {
                dynamic agentWrapper = new AccessPrivateWrapper(agent);

                // Get at the underling Agent
                agentWrapper = new AccessPrivateWrapper(agentWrapper.AgentInformation);
                dynamic parentMachineRoleWrapper = new AccessPrivateWrapper(agentWrapper.ParentMachineRole);
                dynamic parentTestEnvironmentWrapper = new AccessPrivateWrapper(parentMachineRoleWrapper.ParentTestEnvironment);

                TestAgentInfo info = new TestAgentInfo() { MachineName = agentWrapper.MachineName, AgentName = agentWrapper.Name, ParentMachineRoleName = parentMachineRoleWrapper.Name, AgentStatus = agentWrapper.Status.ToString(), ParentTestEnvironmentName = parentTestEnvironmentWrapper.Name, RawAgentInformation = agentWrapper };

                result.Add(info);
            }

            return result;
        }



        /// <summary>
        /// Construct a new Physical Environment object. 
        /// </summary>
        public static object ConstructEnvironment(string environmentName, string projectName, Dictionary<string, TestAgentInfo> agents, Dictionary<string, string> machineRoles)
        {
            System.Reflection.Assembly controllerAssembly = System.Reflection.Assembly.LoadFile(ControllerExecutionCommonAssemblyPath);
            Type controllerTestEnvironmentType = controllerAssembly.GetType(controllerTestEnvironmentTypeName);
            Type machineRoleType = controllerAssembly.GetType(controllerMachineRoleTypeName);

            object testEnvironment = controllerTestEnvironmentType.InvokeMember("", System.Reflection.BindingFlags.CreateInstance, null, controllerTestEnvironmentType, null);
            dynamic testEnvironmentWrapper = new AccessPrivateWrapper(testEnvironment);

            // 1. Set up the stock environment parameters.
            // 2. Duplicate all of the Agents that were selected. This clone copies information about the Agent but not the environment. The environment gets set when we add
            //    the MachineRole.
            // 3. Add all MachineRoles
            //    3a. If there are any Agents that have set that as the MachineRole, add it. 

            // 1.
            testEnvironmentWrapper.Description = "Some description for " + environmentName;
            testEnvironmentWrapper.Name = environmentName;
            testEnvironmentWrapper.TeamProjectName = projectName;

            // 2.
            Dictionary<string, object> newAgents = new Dictionary<string, object>();

            foreach (KeyValuePair<string, TestAgentInfo> pair in agents)
            {
                object agentInformation = (pair.Value.RawAgentInformation as dynamic).DeepClone();

                newAgents[pair.Key] = agentInformation;
            }

            // 3.
            foreach (KeyValuePair<string, string> pair in machineRoles)
            {
                object machineRole = machineRoleType.InvokeMember("", System.Reflection.BindingFlags.CreateInstance, null, machineRoleType, new object[] { pair.Key });

                testEnvironmentWrapper.AddMachineRole(machineRole);

                foreach (KeyValuePair<string, TestAgentInfo> tiPair in agents)
                {
                    if (tiPair.Value.ParentMachineRoleName == pair.Key)
                    {
                        dynamic machineRoleWrapper = new AccessPrivateWrapper(machineRole);

                        // The machineRole Wrapper will set the ParentEnvironment of any Agents added to it.
                        machineRoleWrapper.AddAgent(newAgents[tiPair.Key]);

                        continue;
                    }
                }
            }

            // 4. This helper function in the library can throw all kinds of useful error messages. 
            testEnvironmentWrapper.Validate();

            return testEnvironment;
        }



        /// <summary>
        /// Persist a constructed environment. 
        /// </summary>
        public static void CreateEnvironment(string controllerUri, object testEnvironment)
        {
            System.Reflection.Assembly controllerAssembly = System.Reflection.Assembly.LoadFile(ControllerAssemblyPath);

            Type controllerConnectionManagerType = controllerAssembly.GetType(controllerConnectionManagerTypeName);

            object controllerConnectionManager = controllerConnectionManagerType.InvokeMember("Connect", System.Reflection.BindingFlags.InvokeMethod, null, controllerConnectionManagerType, new object[] { controllerUri });
            dynamic controllerConnectionManagerWrapper = new AccessPrivateWrapper(controllerConnectionManager);

            controllerConnectionManagerWrapper.UpdateTestEnvironment(testEnvironment);
        }
    }
}
