﻿// Module:      AgentHelpers
//
// Author:      Graham Stephenson (www.havecomputerwillcode.com/blog)
//
// Purpose:     Provide a way of automating the construction of Physical Environments containing Test Controllers and Test Agents with Roles.
//
// Disclaimer:  Do not use under any circumstances! (That should just about cover it!)
//
// NOTES:       Reuse this code wherever you like, but please credit the original author and link to the blog. Cheers!
//

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AgentHelpers
{
    /// <summary>
    /// Used to describe a machine with a Test Agent installed. 
    /// </summary>
    public class TestAgentInfo
    {
        /// <summary>
        /// Agent Name.
        /// </summary>
        public string AgentName
        {
            get;
            set;
        }

        /// <summary>
        /// Machine Name.
        /// </summary>
        public string MachineName
        {
            get;
            set;
        }

        /// <summary>
        /// Agent Status.
        /// </summary>
        public string AgentStatus
        {
            get;
            set;
        }

        /// <summary>
        /// Role name of the Agent Machine. 
        /// </summary>
        public string ParentMachineRoleName
        {
            get;
            set;
        }


        /// <summary>
        /// Parent Test Environment Name. 
        /// </summary>
        public string ParentTestEnvironmentName
        {
            get;
            set;
        }


        /// <summary>
        /// Raw (underlying) agent object. 
        /// </summary>
        public object RawAgentInformation;
    }
}
