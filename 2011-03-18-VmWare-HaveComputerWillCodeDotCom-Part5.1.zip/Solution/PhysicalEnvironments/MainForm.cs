﻿// Module:      PhysicalEnvironments
//
// Author:      Graham Stephenson (www.havecomputerwillcode.com/blog)
//
// Purpose:     Provide a way of automating the construction of Physical Environments containing Test Controllers and Test Agents with Roles.
//
// Disclaimer:  Do not use under any circumstances! (That should just about cover it!)
//
// NOTES:       Reuse this code wherever you like, but please credit the original author and link to the blog. Cheers!
//


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Microsoft.TeamFoundation.Client;
using System.Security.Principal;
using Microsoft.TeamFoundation.TestManagement.Client;
using System.ServiceModel;
using System.Reflection;
using System.Dynamic;
using System.Collections.ObjectModel;
using System.Collections;
using AgentHelpers;

namespace PhysicalEnvironments
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();

            TestControllers = new Dictionary<string, ITestController>();
        }

        private void buttonConnect_Click(object sender, EventArgs e)
        {
            // 1. We'll use the standard TFS Project Picker. 
            // 2. Display picker. 
            // 3. Update controls based on selection. 
            // 4. Store selections. 
            // 5. Get the Test Controllers available this Team Project Collection / Team Project. 

            // 1.
            TeamProjectPicker picker = new TeamProjectPicker(TeamProjectPickerMode.SingleProject, false);

            // 2.
            DialogResult result = picker.ShowDialog();
            if (result != System.Windows.Forms.DialogResult.OK) return;
            if (picker.SelectedProjects.Length == 0) return;

            // 3.
            textBoxProjectCollection.Text = picker.SelectedTeamProjectCollection.Name;
            textBoxTeamProjectUri.Text = picker.SelectedProjects[0].Uri;
            textBoxTeamProject.Text = picker.SelectedProjects[0].Name;

            // 4.
            ProjectCollection = picker.SelectedTeamProjectCollection;
            ProjectInfo = picker.SelectedProjects[0];
            ProjectName = textBoxTeamProject.Text;

            // 5.
            GetTestControllers();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            listBoxTestControllers.SelectedIndexChanged += new EventHandler(listBoxTestControllers_SelectedIndexChanged);
        }

        void listBoxTestControllers_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = (sender as ListBox).SelectedIndex;
            if (index < 0) return;

            Cursor.Current = Cursors.WaitCursor;
            try
            {
                dataGridViewAgentsInUse.DataSource = null;

                string controller = (sender as ListBox).Items[index].ToString();
                ITestController pe = TestControllers[controller];

                textBoxControllerUri.Text = pe.Name;

                // Now pull out all of the Agents for all of the environments. 
                IEnumerable<TestAgentInfo> list = Helpers.GetAllAgents(pe.Name);

                List<TestAgentInfo> alreadyInUse = new List<TestAgentInfo>(list.Where<TestAgentInfo>(f => f.ParentTestEnvironmentName != "Default"));
                List<TestAgentInfo> available = new List<TestAgentInfo>(list.Where<TestAgentInfo>(f => f.ParentTestEnvironmentName == "Default"));
                List<TestAgentCandidate> candidates = new List<TestAgentCandidate>();
                foreach (TestAgentInfo ai in available)
                {
                    candidates.Add(new TestAgentCandidate() { AgentName = ai.AgentName, IncludeInEnvironment = false, ParentMachineRoleName = "Moo" });
                }

                dataGridViewAgentsInUse.DataSource = alreadyInUse;
                dataGridViewAvailableAgents.DataSource = candidates;

                TestAgents = available;
            }
            finally
            {
                Cursor.Current = Cursors.Default;
            } 
        }

        /// <summary>
        /// Gets the Test Controllers available via TFS and renders them in the List View. 
        /// </summary>
        private void GetTestControllers()
        {
            tabControlActions.Visible = true;

            // Create a new Physical Environment. First we need to list the available controllers.
            IEnumerable<ITestController> controllers = Helpers.EnumerateTestControllers(ProjectCollection);
            TestControllers.Clear();

            foreach (ITestController controller in controllers)
            {
                TestControllers[controller.DisplayName] = controller;
                listBoxTestControllers.Items.Add(controller.DisplayName);
            }
        }

        private void buttonCreate_Click(object sender, EventArgs e)
        {
            List<TestAgentCandidate> candidates = dataGridViewAvailableAgents.DataSource as List<TestAgentCandidate>;
            if (candidates == null) throw new System.ArgumentNullException("No Agents Available To Add To Environment");

            if (String.IsNullOrWhiteSpace(textBoxEnvironmentName.Text)) throw new System.ArgumentNullException("Enter a new Physical Environment Name");

            Dictionary<string, TestAgentInfo> agentsToAdd = new Dictionary<string, TestAgentInfo>();
            Dictionary<string, string> machineRoleInfo = new Dictionary<string, string>();

            foreach (TestAgentCandidate candidate in candidates)
            {
                if (!candidate.IncludeInEnvironment) continue;

                // Find the Agent we are going to be dealing with. 
                TestAgentInfo info = TestAgents.First<TestAgentInfo>(f => f.AgentName == candidate.AgentName);

                // We want to use the new role name... 
                info.ParentMachineRoleName = candidate.ParentMachineRoleName;

                agentsToAdd[info.AgentName] = info;
                machineRoleInfo[candidate.ParentMachineRoleName] = "";
            }

            if (agentsToAdd.Count == 0) throw new System.ArgumentOutOfRangeException("No agents were selected");

            // ASSERTION: agentsToAdd contains the Agents we will be adding to the new environment. 

            object theEnvironment = Helpers.ConstructEnvironment(textBoxEnvironmentName.Text, ProjectName, agentsToAdd, machineRoleInfo);

            Helpers.CreateEnvironment(textBoxControllerUri.Text, theEnvironment);
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
            Close();
        }

        private Microsoft.TeamFoundation.Server.ProjectInfo ProjectInfo;
        private TfsTeamProjectCollection ProjectCollection;
        private string ProjectName; 
       
        private Dictionary<string, ITestController> TestControllers;
        private IEnumerable<TestAgentInfo> TestAgents;
    }
}
