﻿// Module:      AgentInteraction
//
// Author:      Graham Stephenson (www.havecomputerwillcode.com/blog)
//
// Purpose:     Provide a way of automating the construction of Physical Environments containing Test Controllers and Test Agents with Roles.
//
// Disclaimer:  Do not use under any circumstances! (That should just about cover it!)
//
// NOTES:       Reuse this code wherever you like, but please credit the original author and link to the blog. Cheers!
//

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AgentInteraction
{
    public enum Commands
    {
        None = 0,
        ListAgents = 1,
        RegisterEnvironment = 2,
        WaitForTestReady = 3
    }

    public class Arguments
    {
        public Commands Command;
        public string TeamProjectName;
        public string TestControllerUri;
        public string EnvironmentName;
        public int RetryCount;
        public Dictionary<string, string> Agents = new Dictionary<string,string>();
        public Dictionary<string, string> Roles = new Dictionary<string, string>();
    }

    public class CheesyParser
    {
        public static Arguments Parse(string[] args)
        {
            Arguments arguments = new Arguments();

            foreach (string s2 in args)
            {
                string s = s2.ToUpper();

                if (s.StartsWith("COMMAND="))
                {
                    string command = s2.Substring("COMMAND=".Length);

                    arguments.Command = (Commands) System.Enum.Parse(typeof(Commands), command, true);
                }
                else if(s.StartsWith("TEAMPROJECTNAME="))
                {
                    arguments.TeamProjectName = s2.Substring("TEAMPROJECTNAME=".Length).Replace(@"""", "");
                }
                else if (s.StartsWith("TESTCONTROLLERURI="))
                {
                    arguments.TestControllerUri = s2.Substring("TESTCONTROLLERURI=".Length).Replace(@"""", ""); ;
                }
                else if (s.StartsWith("AGENTS="))
                {
                    string agents = s2.Substring("AGENTS=".Length).Replace(@"""", "");

                    string[] theAgents = agents.Split('|');

                    foreach (string theAgent in theAgents)
                    {
                        string[] theAgentAndRole = theAgent.Split(',');

                        // No error checking... glorious!
                        string theAgentName = theAgentAndRole[0];
                        string theAgentRole = theAgentAndRole[1];

                        arguments.Agents[theAgentName] = theAgentRole;
                        arguments.Roles[theAgentRole] = "";
                    }
                }
                else if (s.StartsWith("ENVIRONMENTNAME="))
                {
                    arguments.EnvironmentName = s2.Substring("ENVIRONMENTNAME=".Length).Replace(@"""", ""); ;
                }
                else if (s.StartsWith("RETRYCOUNT="))
                {
                    arguments.RetryCount = System.Convert.ToInt32(s2.Substring("RETRYCOUNT=".Length).Replace(@"""", ""));
                }
            }

            return arguments;
        }
    }
}
