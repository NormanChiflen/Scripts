﻿// Module:      AgentInteraction
//
// Author:      Graham Stephenson (www.havecomputerwillcode.com/blog)
//
// Purpose:     Provide a way of automating the construction of Physical Environments containing Test Controllers and Test Agents with Roles.
//
// Disclaimer:  Do not use under any circumstances! (That should just about cover it!)
//
// NOTES:       Reuse this code wherever you like, but please credit the original author and link to the blog. Cheers!
//

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PhysicalEnvironments;
using AgentHelpers;

namespace AgentInteraction
{
    class Program
    {
        static void Main(string[] args)
        {
            System.Console.WriteLine("AgentInteraction v0.1 - www.havecomputerwillcode.com/blog (Graham Stephenson)");
            System.Console.WriteLine("-----------------------------------------------------------------------------");
            System.Console.WriteLine("Use at your own risk!");
            System.Console.WriteLine(""); 
            
            // 1. Sanitize
            // 2. Execute

            Arguments arguments = CheesyParser.Parse(args);

            // 1.
            switch (arguments.Command)
            {
                case Commands.None:
                    System.Console.WriteLine("Invalid Command. Use: COMMAND=LISTAGENTS|REGISTERENVIRONMENT");
                    return;
                case Commands.ListAgents:
                    if (String.IsNullOrWhiteSpace(arguments.TestControllerUri))
                    {
                        System.Console.WriteLine("ERROR: Use COMMAND=LISTAGENTS TESTCONTROLLERURI=[TestControllerURI]");
                        System.Console.WriteLine("EXAMPLE: Use COMMAND=LISTAGENTS TESTCONTROLLERURI=THEMACHINE.WOOHOO.COM:6901");
                    }
                    else
                    {
                        System.Console.WriteLine("Listing Agents on Controller '" + arguments.TestControllerUri + "' for Team Project '" + arguments.TeamProjectName + "'");
                        System.Console.WriteLine("This might take a while...");
                    }
                    return;
                case Commands.RegisterEnvironment:
                    {
                        bool inError = String.IsNullOrWhiteSpace(arguments.TeamProjectName) || String.IsNullOrWhiteSpace(arguments.EnvironmentName) || String.IsNullOrWhiteSpace(arguments.TestControllerUri) || arguments.Agents.Count == 0;

                        if (inError)
                        {
                            System.Console.WriteLine("ERROR: Use COMMAND=REGISTERENVIRONMENT TEAMPROJECTNAME=[TeamProjectName] ENVIRONMENTNAME=[YourEnvironmentName] TESTCONTROLLERURI=[TestControllerUri] AGENTS=[AgentList] [RETRYCOUNT=[Retries]]");
                            System.Console.WriteLine(@"EXAMPLE: Use COMMAND=REGISTERENVIRONMENT TEAMPROJECTNAME=""TestSample""  TESTCONTROLLERURI=""THEMACHINE.WOOHOO.COM:6901"" ENVIRONMENTNAME=""My Environment"" AGENTS=""MOO1251,Desktop Client|MOO1252,Web Server"" RETRYCOUNT=5 ");

                            return;
                        }
                        else
                        {
                            System.Console.WriteLine("Creating Environment on Test Controller '" + arguments.TestControllerUri + "' for Team Project '" + arguments.TeamProjectName + "' called '" + arguments.EnvironmentName + "'");
                            System.Console.WriteLine("This might take a while...");
                        }
                    }
                    break;
            }

            // 2.
            arguments.RetryCount = Math.Max(1, arguments.RetryCount);

            int currentTry = 1;

            while (currentTry <= arguments.RetryCount)
            {
                System.Console.WriteLine("Attempt {0}...", currentTry);

                try
                {
                    switch (arguments.Command)
                    {
                        case Commands.ListAgents:
                            ListAgents(arguments.TestControllerUri);
                            break;
                        case Commands.RegisterEnvironment:
                            {
                                IEnumerable<TestAgentInfo> agents = AgentHelpers.Helpers.GetAllAgents(arguments.TestControllerUri);

                                Dictionary<string, TestAgentInfo> agentsToAdd = new Dictionary<string, TestAgentInfo>();

                                foreach (KeyValuePair<string, string> pair in arguments.Agents)
                                {
                                    // Find the Agent Info we need to work with. 
                                    TestAgentInfo info = agents.First<TestAgentInfo>(f => String.Compare(f.AgentName, pair.Key, true) == 0);

                                    // We want to use the new role name... 
                                    info.ParentMachineRoleName = pair.Value;

                                    agentsToAdd[info.AgentName] = info;
                                }

                                // ASSERTION: agentsToAdd contains the Agents we will be adding to the new environment. 
                                object theEnvironment = Helpers.ConstructEnvironment(arguments.EnvironmentName, arguments.TeamProjectName, agentsToAdd, arguments.Roles);

                                Helpers.CreateEnvironment(arguments.TestControllerUri, theEnvironment);
                                System.Console.WriteLine("DONE!");
                                return;
                            }
                        default:
                            break;
                    }

                    return;
                }
                catch (Exception e)
                {
                    if(currentTry == arguments.RetryCount)
                    {
                        System.Console.WriteLine(e.Message);
                        return;
                    }
                }

                currentTry++;
            }
        }

        static void ListAgents(string testControllerUri)
        {
            IEnumerable<TestAgentInfo> agents = AgentHelpers.Helpers.GetAllAgents(testControllerUri);

            foreach(TestAgentInfo info in agents)
            {
                System.Console.WriteLine(String.Format("{0},{1},{2}", info.AgentName, info.ParentMachineRoleName, info.AgentStatus));
            }
        }
    }
}
