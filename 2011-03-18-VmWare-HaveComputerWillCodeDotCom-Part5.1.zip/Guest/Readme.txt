To set this up to make VmRun.EXE easier to work with:

Copy the SCRIPTS\ contents to C:\Scripts\ on your Golden Virtual Machine Image. 

- www.havecomputerwillcode.com/blog
