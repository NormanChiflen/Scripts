# Module:      Helpers.PS1
#
# Source:      www.havecomputerwillcode.com/blog
#
# Author:      Graham Stephenson
# Date:        18-March-2011
#
# NOTES:       Before running this, install the latest VIX and add VMRUN.EXE to your path. 
#              There is NO Error Checking in this. Good luck!
#
# Disclaimer:  DO NOT USE THIS CODE UNDER ANY CIRCUMSTANCES WHATSOEVER (that should just about cover it!)
#

# Wrapper function for launching VMRUN.EXE with the specified arguments.
#
function global:LaunchHelper
{
	param([Parameter(Mandatory=$true)] [String] $theArguments)

	# You must have "VmRun.EXE" in your Path for this to work...
	Write-Host "Launching the command:"
	Write-Host "vmrun.exe $($theArguments)"
	Write-Host "";
	
	Invoke-Expression "vmrun.exe $($theArguments)";
}



# Will construct an Authentication String that is passed to VmRun.EXE.
#
function global:GetAuthenticationString
{
    param([Parameter(Mandatory=$true)] [object] $theConnectionParameters)
	
	if($theConnectionParameters["VmWareHostType"] -eq "ws")
	{
		return "-T ws ";
	}
	
	if($theConnectionParameters["VmWareHostType"] -eq "server")
	{
		return "-T server -h https://$($theConnectionParameters[`"VmWareHostName`"]):$($theConnectionParameters[`"VmWareHostPort`"])/sdk -u $($theConnectionParameters[`"VmWareUsername`"]) -p $($theConnectionParameters[`"VmWarePassword`"]) ";
	}
}



# Clone a Virtual Machine
#
# NOTE: With VmWare WOrkstation (which I do not have) I think the call to 'clone' will work - please let me know!
#       With VmWare Server, Clone is not supported from VmRun so instead I create a Snapshot called 'Dynamic' every time this function is called. Subsequent calls cause the first snapshot
#            to be overwritten. 
#
function global:CloneVirtualMachine
{
    param([Parameter(Mandatory=$true)] [object] $theConnectionParameters,
	      [Parameter(Mandatory=$true)] [string] $theGoldenImageSourceLocation,
	      [Parameter(Mandatory=$true)] [string] $theGoldenImageTargetLocation)
		 
	$connectionString = GetAuthenticationString($theConnectionParameters);
	
	if($theConnectionParameters["VmWareHostType"] -eq "ws")
	{
		$cloneCommand = "$($connectionString) clone `"$($theGoldenImageSourceLocation)`" `"$($theGoldenImageTargetLocation)`" full";
		
		LaunchHelper $cloneCommand;
	}
	elseif($theConnectionParameters["VmWareHostType"] -eq "server")
	{
	    # We cannot Clone in VmWare Server so I just revert to a previous snapshot so I can run the script repeatedly. Hunt around and see if you can find a way of really Cloning a VmWare Server image and put
		# put that logic here. 
		$cloneCommand = "$($connectionString) revertToSnapshot `"$($theGoldenImageSourceLocation)`" `"ItDoesNotMatterWhatThisIsCalled`"";
		
		LaunchHelper $cloneCommand;
	}
}



# List all Virtual Machines in VmWare Workstation or VmWare Server.
#
function global:ListVirtualMachines
{
    param([Parameter(Mandatory=$true)] [object] $theConnectionParameters)
	
	$connectionString = GetAuthenticationString($theConnectionParameters);
	
	$listCommand = "$connectionString listRegisteredVM";
	
	LaunchHelper $listCommand;
}



# Start a virtual machine
#
function global:StartVirtualMachine
{
    param([Parameter(Mandatory=$true)] [object] $theConnectionParameters,
	      [Parameter(Mandatory=$true)] [string] $theClonedImageLocation,
		  [Parameter(Mandatory=$true)] [string] $theGuestUsername,
		  [Parameter(Mandatory=$true)] [string] $theGuestPassword)
	
	$connectionString = GetAuthenticationString($theConnectionParameters);
	
	$startCommand = "$connectionString -gu $theGuestUsername -gp $theGuestPassword start `"$theClonedImageLocation`" gui ";
	
	LaunchHelper $startCommand;
}



# Renames a virtual machine by running the RenameMachine.Vbs script within it. 
#
function global:RenameVirtualMachine
{
    param([Parameter(Mandatory=$true)] [object] $theConnectionParameters,
	      [Parameter(Mandatory=$true)] [string] $theClonedImageLocation,
		  [Parameter(Mandatory=$true)] [string] $theGuestUsername,
		  [Parameter(Mandatory=$true)] [string] $theGuestPassword,
		  [Parameter(Mandatory=$true)] [string] $theNewMachineName)
	
    $connectionString = GetAuthenticationString($theConnectionParameters);
	
	$renameCommand = "$connectionString -gu $theGuestUsername -gp $theGuestPassword runProgramInGuest `"$theClonedImageLocation`" `"C:\Windows\System32\CMD.EXE`" /C C:\scripts\RenameMachine.BAT $theNewMachineName ";
	
	LaunchHelper $renameCommand;
}



# Joins the machine to a domain. 
#
function global:JoinVirtualMachineToDomain
{
    param([Parameter(Mandatory=$true)] [object] $theConnectionParameters,
	      [Parameter(Mandatory=$true)] [string] $theClonedImageLocation,
		  [Parameter(Mandatory=$true)] [string] $theGuestUsername,
		  [Parameter(Mandatory=$true)] [string] $theGuestPassword,
		  [Parameter(Mandatory=$true)] [string] $theDomainAdministratorUsername,
		  [Parameter(Mandatory=$true)] [string] $theDomainAdministratorPassword,
		  [Parameter(Mandatory=$true)] [string] $theDomainName)
		  
    $connectionString = GetAuthenticationString($theConnectionParameters);

	$joinCommand = "$connectionString -gu $theGuestUsername -gp $theGuestPassword runProgramInGuest `"$theClonedImageLocation`" `"C:\Windows\System32\CMD.EXE`" /C C:\scripts\JoinDomain.BAT $theDomainAdministratorUsername $theDomainAdministratorPassword $theDomainName ";
	
	LaunchHelper $joinCommand;
}


# Stop a virtual machine
#
function global:StopVirtualMachine
{
    param([Parameter(Mandatory=$true)] [object] $theConnectionParameters,
	      [Parameter(Mandatory=$true)] [string] $theClonedImageLocation,
		  [Parameter(Mandatory=$true)] [string] $theGuestUsername,
		  [Parameter(Mandatory=$true)] [string] $theGuestPassword)
		  
	$connectionString = GetAuthenticationString($theConnectionParameters);
	
	$stopCommand =  "$connectionString -gu $theGuestUsername -gp $theGuestPassword stop `"$theClonedImageLocation`" soft ";
	
	LaunchHelper $stopCommand;
}



# Install the Test Controller. 
#
function global:InstallTestController
{
    param([Parameter(Mandatory=$true)] [object] $theConnectionParameters,
	      [Parameter(Mandatory=$true)] [string] $theClonedImageLocation,
		  [Parameter(Mandatory=$true)] [string] $theGuestUsername,
		  [Parameter(Mandatory=$true)] [string] $theGuestPassword,
		  [Parameter(Mandatory=$true)] [string] $theVisualStudioGumpfUnc)
		  
    $connectionString = GetAuthenticationString($theConnectionParameters);

	$installCommand = "$connectionString -gu $theGuestUsername -gp $theGuestPassword runProgramInGuest `"$theClonedImageLocation`" `"C:\Windows\System32\CMD.EXE`" /C C:\scripts\InstallTestController.BAT $theVisualStudioGumpfUnc ";
	
	LaunchHelper $installCommand;
}



# Install the Test Agent. 
#
function global:InstallTestAgent
{
    param([Parameter(Mandatory=$true)] [object] $theConnectionParameters,
	      [Parameter(Mandatory=$true)] [string] $theClonedImageLocation,
		  [Parameter(Mandatory=$true)] [string] $theGuestUsername,
		  [Parameter(Mandatory=$true)] [string] $theGuestPassword,
		  [Parameter(Mandatory=$true)] [string] $theVisualStudioGumpfUnc)
		  
    $connectionString = GetAuthenticationString($theConnectionParameters);

	$installCommand = "$connectionString -gu $theGuestUsername -gp $theGuestPassword runProgramInGuest `"$theClonedImageLocation`" `"C:\Windows\System32\CMD.EXE`" /C C:\scripts\InstallTestAgent.BAT $theVisualStudioGumpfUnc ";
	
	LaunchHelper $installCommand;
}



# Install the Test Patches. 
#
function global:InstallTestPatches
{
    param([Parameter(Mandatory=$true)] [object] $theConnectionParameters,
	      [Parameter(Mandatory=$true)] [string] $theClonedImageLocation,
		  [Parameter(Mandatory=$true)] [string] $theGuestUsername,
		  [Parameter(Mandatory=$true)] [string] $theGuestPassword,
		  [Parameter(Mandatory=$true)] [string] $theVisualStudioGumpfUnc)
		  
    $connectionString = GetAuthenticationString($theConnectionParameters);

	$installCommand = "$connectionString -gu $theGuestUsername -gp $theGuestPassword runProgramInGuest `"$theClonedImageLocation`" `"C:\Windows\System32\CMD.EXE`" /C C:\scripts\InstallTestPatches.BAT $theVisualStudioGumpfUnc ";
	
	LaunchHelper $installCommand;
}



# Configure the Test Controller. 
#
function global:ConfigureTestController
{
    param([Parameter(Mandatory=$true)] [object] $theConnectionParameters,
	      [Parameter(Mandatory=$true)] [string] $theClonedImageLocation,
		  [Parameter(Mandatory=$true)] [string] $theGuestUsername,
		  [Parameter(Mandatory=$true)] [string] $theGuestPassword,
		  [Parameter(Mandatory=$true)] [string] $theTestControllerTfsProjectCollection,
		  [Parameter(Mandatory=$true)] [string] $theTestControllerServiceUser,
		  [Parameter(Mandatory=$true)] [string] $theTestControllerServicePassword)
		  
    $connectionString = GetAuthenticationString($theConnectionParameters);

	$configureCommand = "$connectionString -gu $theGuestUsername -gp $theGuestPassword runProgramInGuest `"$theClonedImageLocation`" `"C:\Windows\System32\CMD.EXE`" /C C:\scripts\ConfigureTestController.BAT $theTestControllerTfsProjectCollection $theTestControllerServiceUser $theTestControllerServicePassword SomeFillerSoTheParameterGetsPassedThrough ";
	
	LaunchHelper $configureCommand;
}



# Configure the Test Agent. 
#
function global:ConfigureTestAgent
{
    param([Parameter(Mandatory=$true)] [object] $theConnectionParameters,
	      [Parameter(Mandatory=$true)] [string] $theClonedImageLocation,
		  [Parameter(Mandatory=$true)] [string] $theGuestUsername,
		  [Parameter(Mandatory=$true)] [string] $theGuestPassword,
		  [Parameter(Mandatory=$true)] [string] $theTestProcessUsername,
		  [Parameter(Mandatory=$true)] [string] $theTestProcessPassword,
		  [Parameter(Mandatory=$true)] [string] $theTestControllerUri)
		  
    $connectionString = GetAuthenticationString($theConnectionParameters);

	$configureCommand = "$connectionString -gu $theGuestUsername -gp $theGuestPassword runProgramInGuest `"$theClonedImageLocation`" `"C:\Windows\System32\CMD.EXE`" /C C:\scripts\ConfigureTestAgent.BAT $theTestProcessUsername $theTestProcessPassword $theTestControllerUri SomeFillerSoTheParameterGetsPassedThrough ";
	
	LaunchHelper $configureCommand;
}
