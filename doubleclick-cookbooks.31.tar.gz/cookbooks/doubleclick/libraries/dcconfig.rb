require_relative 'dcutils'

class DoubleClickConfig
include DCUtils

    attr_reader :component_map, :user, :group, :comp_conf_dir, :deploy_home, :deploy_log_dir, :host, :l_general, :l_monitor, :l_ss_status, :l_sys_info, :email, :env, :basedir, :comp_name
    def initialize()
	@user = 'dart'
	@group = 'cxappeng'
	@basedir = File.dirname(File.dirname(__FILE__))
        @comp_map_hash = build_component_map( File.open(@basedir + "/config/component_info.yml") )
	@deploy_home = "/opt/dartenterprise/dc_deploy"
	@deploy_log_dir = @deploy_home + "/logs"
	@host = Socket.gethostname.split(".")[0]
	#@comp_conf_dir = basedir + File::SEPARATOR + "config" + File::SEPARATOR + @comp_name
    end

    def init()
	@l_general = DCLogger.createLogger(@deploy_log_dir + "/dc_deploy.log")
	@l_monitor = DCLogger.createLogger(@deploy_log_dir + "/dc_monitor.log")
	@l_ss_status = DCLogger.createLogger(@deploy_log_dir + "/ssocket_info.log")
	@l_sys_info = DCLogger.createLogger(@deploy_log_dir + "/sys_info.log")
	@comp_name = get_component(@comp_map_hash)
	@env = get_env(@comp_map_hash)
	@email = YAML::load( File.open(@basedir + "/config/component_info.yml"))["email"][@env]
	@comp_conf_dir = @basedir + File::SEPARATOR + "config"
	if @comp_name
	    @comp_conf_dir = @comp_conf_dir + File::SEPARATOR + @comp_name
	end
    end

    def get_monitor_files()
	f_hash = { 'sys_info.log' => @deploy_log_dir + "/dc_deploy.log" , 'ssocket_info.log' => @deploy_log_dir + "/ssocket_info.log" ,
		   'sys_info.log' => @deploy_log_dir + "/sys_info.log"  }
    end
end

#DCConfig = DoubleClickConfig.new()

