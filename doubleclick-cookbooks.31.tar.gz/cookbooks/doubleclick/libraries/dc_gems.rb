require 'rubygems'
require 'pp'
require 'socket'
require 'yaml'

begin 
 require 'pony'
 require 'log4r'
 include Log4r
rescue Exception => e
 puts " skipping log modules ........ "
end 

require_relative 'dclogger'
require_relative 'dcutils'
include DCUtils
require_relative 'dcconfig'
require_relative 'component'
require_relative 'dcmail'
require_relative 'dcmonitor'

DCConfig = DoubleClickConfig.new()
DCConfig.init()

#### delcare global vars and objects 
##DC_USER = 'dart'
##DC_GROUP = 'cxappeng'
##CHEF_BASEDIR = File.dirname(File.dirname(__FILE__))

##DEPLOY_BASE = "/opt/dartenterprise/dc_deploy"
##DEPLOY_LOG = DEPLOY_BASE+"/logs"
##LOGGER = DCLogger.getLogger()
##HOST = Socket.gethostname.split(".")[0]

##COMP_INFO = build_component_map( File.open(CHEF_BASEDIR + "/config/component_info.yml") )

##DC_ENV = get_env(COMP_INFO)
##DC_COMPONENT = get_component(COMP_INFO)
##DC_CONFIG_BASE = CHEF_BASEDIR + File::SEPARATOR + "config" + File::SEPARATOR + DC_COMPONENT

#### end


