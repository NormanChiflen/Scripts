

class DCMonitor

     def initialize(component,opts={})
	 @comp_inst = component
         puts " init monitor "
     end

     def log_gemlist() 

     end

     def log_env()

     end

     def log_space()
	 du_out=`df`
	 log(DCConfig.l_sys_info,:info, du_out)
	 puts " \n\n\n"
	 pp DCConfig.l_sys_info
     end

     def get_ss_cloud_info()
	cmd = DCConfig.basedir + "/bin/GetsscloudInfo.sh"
	pp cmd
	ss_out=`#{cmd}`
	log(DCConfig.l_ss_status,:info, ss_out)
     end 

     def send_monitor_info() 
	 mon_log_files = DCConfig.get_monitor_files()
	pp mon_log_files
	 DCMail.notify_mail("DoubleClick Monitor",:success," Sending information captured by monitor. \n Please see attachment.",mon_log_files)
     end
end

