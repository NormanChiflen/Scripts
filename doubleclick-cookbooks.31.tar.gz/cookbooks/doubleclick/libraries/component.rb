require_relative 'utils'

class Component

#    include Utils

    def initialize(config_dir)
        @serviceDir = "/etc/init.d"
        yaml = config_dir + "/metadata.yml"
	pp yaml
        config = YAML::load( File.open( yaml ) )
	pp config
        @services = config['service_info']
        @files = config['file_info']
        @config_dir = DCConfig.comp_conf_dir
    end

   attr_accessor :services, :files
   def verify_coonfig()
#### TODO
# 1) verify server == env and component
# 2) verify db connection for admanager
# 3) verify 
    end

    def copy_file(from,to,permission="644",owner=DCConfig.user)
       #### TODO 
       # verify to and from exists
        execute_command("cp #{from} #{to}")
        execute_command("chown #{owner} #{to}")
        execute_command("chmod #{permission} #{to}")
    end

    def add_as_init_service(file)
        fromDir = DCConfig.comp_conf_dir + "/services"
	dc_service = @serviceDir + "/" + file
        serviceScript = fromDir + "/" + DCConfig.env + "/" + file
	if(File.exists?("/etc/init.d/#{file}"))
	   DCMail.notify_mail("Before:add_services:",:success,"Sending previous version of service, before updating",{"#{DCConfig.comp_name}_service.sh" => "/etc/init.d/#{file}"})
	end
        copy_file(serviceScript,dc_service,"755","root")
    end

    def stop_service(file)
        stop_command = @serviceDir + "/" + file + " stop "
        execute_command(" #{stop_command} ")
    end

    def start_service(file)
#TODO
        start_command = @serviceDir + "/" + file + " start "
        execute_command(" #{start_command} ")
    end    

    def install_apache(install_cmd)
	sts=execute_command(install_cmd)
	puts " \n\n\n STATUS \n\n\n"
	pp sts
	if ( sts )
	    DCMail.notify_mail(" Deploy Apache ",:success," Please see attachment for apache log.",{"deploy_apache.log" => DCConfig.deploy_log_dir+"/deploy_apache.log" })
	else
	    DCMail.notify_mail(" Deploy Apache failed",:failure," Please see attachment ",{"deploy_apache.log" => DCConfig.deploy_log_dir+"/deploy_apache.log" })
        end
    end 

end

