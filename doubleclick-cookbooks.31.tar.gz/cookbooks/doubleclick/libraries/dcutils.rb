
### TODO
#1) log chef activity 
#2) email chef log and /var/chef/cache/chef-stacktrace.out to adeng
#3) diff_dir
#4) diff_tar 
#5) diff gz 

### end todo

module DCUtils

    def print_seperator(msg)
       puts "\n #{msg} \n"
       80.times{ print "-" }
        puts "\n"
    end

    def execute_command(cmd)
        sts=0
        sts=system(cmd)
        puts " ---------- #{cmd} --------- sts #{sts}  "
        return sts
    end

    def build_component_map(input_map_file)
        map = YAML::load( File.open(input_map_file))["server_info"]
        ret_hash = {}
        ret_hash['sscloud'] = { 'rtserver' => [] , 'rtclient' => [] }
        for comp in map.keys

         if ( map[comp].keys )
           for env in map[comp].keys

            if ( map[comp][env] )
               for host in map[comp][env]
                   hkey_in = host.keys[0]
                   hkey_out = hkey_in.split(".")[0]
                   ret_hash[ hkey_out ] = {}
                   if( host[ hkey_in ] )
                      ret_hash[ hkey_out ]['rtserver'] = host[ hkey_in ]["rtserver"] ? host[ hkey_in ]["rtserver"] : "N"
                   else
                      ret_hash[ hkey_out ]['rtserver'] = "N"
                   end

                   if ( ret_hash[ hkey_out ]['rtserver'] == "Y" )
                      ret_hash['sscloud']['rtserver'].push(hkey_out) 
                   else 
                      ret_hash['sscloud']['rtclient'].push(hkey_out)
                   end

                   ret_hash[ hkey_out ]['component'] = comp
                   ret_hash[ hkey_out ]['env'] = env
               end
           end

           end
         end

        end

        return ret_hash 
    end 

    def get_env(inp_hash)
        if ( inp_hash[DCConfig.host] && inp_hash[DCConfig.host]["env"] )
           return inp_hash[DCConfig.host]["env"]
        else 
           #raise " This server is not a doubleclick component, please check component_info.yml "
        end
    end

    def get_component(inp_hash)
        if ( inp_hash[DCConfig.host] && inp_hash[DCConfig.host]["component"] )
           return inp_hash[DCConfig.host]["component"]
        else
           #raise " This server is not a doubleclick component, please check component_info.yml "
        end
    end

    def deploy_monitor()

    end

end

