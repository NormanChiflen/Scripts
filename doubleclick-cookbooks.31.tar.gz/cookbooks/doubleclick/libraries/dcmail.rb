
class DCMail

    def self.mail(subject,to,body,attachments={})
	 subject = " #{DCConfig.env.upcase} DC DEployer - " + subject
         from = "dcdeployer-donotreply@expedia.com"
	 body = body.gsub("\n","<br/>")
	 att_list = {}
	 attachments.each { | kk,vv| att_list[kk] = File.read(vv) }
         Pony.mail({:subject => subject, :to => to , :html_body => body , :from => " dc deployer ",:attachments => att_list })
    end

    def self.notify_mail(recipe,status,body,file_list={})
	to = DCConfig.email
	case status
	    when :success
		subject = " Recipe : #{recipe} ran successfully"
	    when :failure
		subject = " Recipe : #{recipe} FAILED , see attachment for details "
		file_list["chef_error.log"] = "/var/chef/cache/chef-stacktrace.out"
	    else
		subject = " unknown status : #{status} send by recipe : #{recipe} please check "
		file_list["chef_error.log"] = "/var/chef/cache/chef-stacktrace.out"
	end
	self.mail(subject,to,body,file_list)
    end

end

#at1=File.read("./mail.rb")
#DCMail.mail(" sub test",["ksathe@expedia.com","kaustubh.sathe@gmail.com"]," body 123 ",{"mail.rb" => at1})

