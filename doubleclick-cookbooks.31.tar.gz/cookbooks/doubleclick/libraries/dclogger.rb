
class  DCLogger
 def self.createLogger(logFilePath)
   begin
     #init_dc_dir()
     #logFilePath = DCConfig.deploy_log + "/dc_deploy.log"
     system(" rm -rf #{logFilePath} ")
     logger = Log4r::Logger.new("dc_deployer")
     pf = PatternFormatter.new(:pattern => "%d thread=%h level=%l logger=%c message=%M%n", :date_pattern => "%d/%m/%y %H:%M:%S %Z")
     logger.outputters = FileOutputter.new("f1", :filename => logFilePath, :formatter => pf)
     return logger
   rescue Exception => e
     puts " expection caught in getLogger "
     return {}
   end

 end

 def self.log(loggerInst,status, *msgs)
     logger = nil

     case status
     when :error
       @load_status = :warn
       logger = lambda { |msg| loggerInst.error(msg) }
     when :fatal
       @load_status = :fatal
       logger = lambda { |msg| loggerInst.fatal(msg) }
     when :info
       logger = lambda { |msg| loggerInst.info(msg) }
     else
       logger = lambda { |msg| loggerInst.debug(msg) }
     end

     msgs.each { |msg| logger.call(msg) }
 end

 #def self.init_dc_dir()
 #     FileUtils.mkdir_p(DCConfig.deploy_log)
 #     system("chown -R  #{DCConfig.user} #{DCConfig.deploy_home}")
 #end

end

# General log function in  global namespace
  def log(logInst,log_level,*msgs)
      DCLogger.log(logInst,log_level,*msgs)
  end 

