
gem_binary = "/opt/chef/embedded/bin/gem"

#install log4r gem
gem_package "log4r" do
#  gem_binary node[:propensity][:rubygem_binary_location]
  action :install
  version "1.1.10"
end

#install pony gem
gem_package "pony" do
  action :install
  version "1.4"
end

gem_info = `gem environment`
gem_list = `gem list`

#DCMail.notify_mail("install_gems",:success,"  Gem installation finished successfully. <br/><br/> Gem env :<br/> #{gem_info}. \n Gem List : #{gem_list} ")

