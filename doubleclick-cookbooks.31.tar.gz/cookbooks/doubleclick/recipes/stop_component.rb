
def stop_message()
  puts " stopping server please wait \n"
  for i in 0..30 do
    sleep(0.5)
    print " ... "
  end

  puts "\n\n Server  stopped \n "

end

component = node[:doubleclick][:lib_comp]

component.services.each { |serv| component.stop_service(serv['file']) 
				stop_message()
				DCMail.notify_mail("stop_component",:success," component #{DCConfig.comp_name} stopped ")
			}

