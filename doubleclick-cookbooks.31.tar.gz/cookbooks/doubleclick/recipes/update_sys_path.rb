
command=" (grep DC_deployer_update  /etc/profile ) || ( echo \"#DC_deployer_update\" >> /etc/profile; echo export PATH=/opt/chef/embedded/bin/:\\\$PATH >> /etc/profile ) "
sts=system(command)

#if sts 
#    DCMail.notify_mail("update_sys_path",:success," Update sys path finished successfully.",{"etc_profile"=>"/etc/profile"})
#else
#    DCMail.notify_mail("update_sys_path",:failure," Update sys path finished with FAILURE.")
#    raise " counld not add chef to PATH varible. Please check /etc/profile file and chef log "
#end

if sts
 system("echo -e \"##############################################################################  \"")
 system("echo -e \"##############################################################################   \n\n\"")
 system("echo PATH was updated, please LOGOUT and LOG back in ")
 system("echo -e \"\n\n##############################################################################   \"")
 system("echo -e \" ##############################################################################  \n\n \"")

else

  raise " counld not add chef to PATH varible. Please check /etc/profile file and chef log "
end

