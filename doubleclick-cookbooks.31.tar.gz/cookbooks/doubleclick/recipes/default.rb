
puts " inside default recipe "


