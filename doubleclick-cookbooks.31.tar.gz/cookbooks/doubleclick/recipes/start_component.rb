
component = node[:doubleclick][:lib_comp]

component.services.each { |serv| component.start_service(serv['file'])
				DCMail.notify_mail("start_component",:success," component #{DCConfig.comp_name} started ")
			 }


