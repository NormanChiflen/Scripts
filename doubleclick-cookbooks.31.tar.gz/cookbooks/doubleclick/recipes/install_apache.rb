
component = node[:doubleclick][:lib_comp]

AP_DIR = DCConfig.comp_conf_dir + "/scripts/deploy_apache"
APACHE_INSTALLER = AP_DIR + "/httpd-2.2.23.tar.gz"
MOD_PY_INSTALLER = AP_DIR + "/mod_python-3.3.1.tgz"

DEP_CMD = AP_DIR+"/deploy_apache_dc.sh " + APACHE_INSTALLER + " " + MOD_PY_INSTALLER

component.install_apache(DEP_CMD)

