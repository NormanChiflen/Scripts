
DCMail.notify_mail("add_user_n_group",:success," Sending existing /etc/group before adding new group",{"etc_group"=>"/etc/group"})

if DCConfig.env != "prod"
  group DCConfig.group do
    action :create
  end
end

DCMail.notify_mail("add_user_n_group",:success," Sending new /etc/group after adding new group",{"etc_group"=>"/etc/group"})

