
component = node[:doubleclick][:lib_comp]

component.services.each { |serv| component.add_as_init_service(serv['file']) 
				 DCMail.notify_mail("add_servie",:success," Service #{serv['file']} was added successfully ")
			}
