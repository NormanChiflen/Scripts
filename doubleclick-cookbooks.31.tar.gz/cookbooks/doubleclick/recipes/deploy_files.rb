
component = node[:doubleclick][:lib_comp]

component.files.each { |ff| component.copy_file( DCConfig.comp_conf_dir + "files/" + ENV + "/" + ff['from'],ff['to']) }


