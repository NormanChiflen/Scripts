
begin 

 comp_inst = Component.new(DCConfig.comp_conf_dir)

 default[:doubleclick][:lib_comp]=comp_inst

rescue Exception => e
 puts " skipping skipping Component because running chef for FIRST TIME ........ "
end

