#!/bin/bash -x

INSTALLER_TAR=$1
MOD_P_INSTALLER=$2
mkdir -p /opt/dartenterprise/dc_deploy/logs/
exec 2>&1 &> /opt/dartenterprise/dc_deploy/logs/deploy_apache.log

SCRIPT_HOME=`pwd`
APACHE_SRC_DIR=/tmp/apache
APACHEINSTALLDIR=/opt/apache_2_2_23
APACHE_BCK=/opt/bck/apache_$(date "+%S%M%H%d%m%y")
APACHE_STATUS="deploy_apache_did_not_run"
MOD_PYTHON_STATUS="mod_python_did_not_run"

echo " Deployment Started $(date) "

function print_line {
echo " ---------------- $1 ----------------------- "
echo
}

function deploy_apache {
mkdir -p $APACHE_BCK
mv $APACHEINSTALLDIR  $APACHE_BCK
rm -rf  $APACHE_SRC_DIR
mkdir $APACHE_SRC_DIR
cp $INSTALLER_TAR $APACHE_SRC_DIR
cd $APACHE_SRC_DIR
tar xzvf $INSTALLER_TAR
dtemp=`basename $INSTALLER_TAR`
pattern=`echo $dtemp | cut -d '.' -f 1`
INSTALL_DIR=`find . -type d -name "$pattern*" `
num=`find . -type d -name "$pattern*" | wc -l1`

if [ "$num" -gt 1 ]
then 
    echo " There are more than 1 directories in $APACHE_SRC_DIR, please check "
    exit 1
fi

cd $INSTALL_DIR

./configure --prefix=$APACHEINSTALLDIR \
LDFLAGS=-L/lib32 \
CPPFLAGS=-m32 \
CFLAGS=-m32 \
--with-mpm=worker \
--enable-mods-shared=all \
--enable-so \
--enable-ssl \
--enable-rewrite=static \
--enable-headers=static \
--enable-expires=static \
--enable-log-config=static \
--enable-nonportable-atomics=yes \
--with-included-apr

make
make install

APACHE_STATUS=$?

}


function install_mod_python {

cd /tmp
rm -rf mod_python
mkdir mod_python
cd mod_python
#wget http://archive.apache.org/dist/httpd/modpython/mod_python-3.3.1.tgz
cd /tmp/mod_python
cp $MOD_P_INSTALLER .
tar xzvf mod_python-3.3.1.tgz
cd mod_python-3.3.1
chmod 755 /opt/python/bin/python2.7
OPT=-32 LDFLAGS=-m32 CFLAGS=-m32 ./configure --with-apxs=$APACHEINSTALLDIR/bin/apxs --with-python=/opt/python/bin/python2.7

make
make install
MOD_PYTHON_STATUS=$?

cd $SCRIPT_HOME
#rm -rf /tmp/mod_python
}

print_line " Begin deploy "

deploy_apache

print_line " installing mod python "

install_mod_python

print_line " Finished deploying apache and mod python "

print_line " finished deploy "

echo " Deployment Finished $(date) "
echo " APACHE exit status = $APACHE_STATUS "
echo " Mod Python exit status = $MOD_PYTHON_STATUS "

