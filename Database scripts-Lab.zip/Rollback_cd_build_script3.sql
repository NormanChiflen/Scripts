/****** Object:  StoredProcedure [dbo].[p_AD_Page_Select]    Script Date: 08/15/2014 15:28:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[p_AD_Page_Select] 
	@Project_ID 	int

AS

select	
	p.Page_ID
,	p.Project_ID
,	p.PageName
,	p.MenuName
from	
	t_AD_Page as p
where
	p.Project_ID = @Project_ID
and	p.DateDeleted is null
order by
	p.PageName

GO
-----------------------------------------------------------------------------------------------------------
/****** Object:  StoredProcedure [dbo].[p_AD_RoleWeb_SelectAccess]    Script Date: 08/15/2014 15:30:10 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[p_AD_RoleWeb_SelectAccess] --1967
	@ProjectName	varchar(50)
,	@PageName		varchar(50)
,	@SectionName	varchar(100)
, 	@Web_ID 		int

AS


if @PageName = '' and @SectionName = ''

	select
		COUNT(pr.Project_ID) as 'Access'
	,	''					 as 'MenuName'
	from
		t_AD_Project as pr
	where 
		pr.ProjectName = @ProjectName
	and	pr.Project_ID in	(
							select	rpr.Project_ID  
							from	t_AD_RoleProject		as rpr
									inner join t_AD_RoleWeb as rw	on rpr.Role_ID = rw.Role_ID 
							where	rw.Web_ID = @Web_ID

							union

							select	Project_ID  
							from	t_AD_WebProject 
							where	Web_ID = @Web_ID
							)	
      
if @PageName <> '' and @SectionName = ''

	select
		COUNT(pa.Page_ID)		as 'Access'
	,	MAX(MenuName)			as 'MenuName'
	from  
		t_AD_Project			as pr 
		inner join t_AD_Page	as pa	on pr.Project_ID = pa.Project_ID
	where 
		pr.ProjectName = @ProjectName
	and	pa.PageName = @PageName
	and pa.Page_ID in	(
						select	rpa.Page_ID  
						from	t_AD_RolePage			as rpa
								inner join t_AD_RoleWeb as rw	on rpa.Role_ID = rw.Role_ID 
						where	rw.Web_ID = @Web_ID
						
						union
						
						select	Page_ID  
						from	t_AD_WebPage 
						where	Web_ID = @Web_ID
						) 
													
if @PageName <> '' and @SectionName <> ''

	select
		COUNT(se.Section_ID)	as 'Access'
	,	''						as 'MenuName'
	from  
		t_AD_Project			as pr 
		inner join t_AD_Page	as pa	on pr.Project_ID = pa.Project_ID 
		inner join t_AD_Section as se	on pa.Page_ID = se.Page_ID
	where 
		pr.ProjectName = @ProjectName
	and	pa.PageName = @PageName
	and se.SectionName = @SectionName
	and se.Section_ID in	(
							select	rse.Section_ID  
							from	t_AD_RoleSection			as rse
									inner join t_AD_RoleWeb		as rw	on rse.Role_ID = rw.Role_ID 
							where	rw.Web_ID = @Web_ID
							
							union
							
							select	Section_ID  
							from	t_AD_WebSection 
							where Web_ID = @Web_ID
							)

GO
-----------------------------------------------------------------------------------
/****** Object:  StoredProcedure [dbo].[p_CT_Passenger_Select]    Script Date: 08/15/2014 15:35:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[p_CT_Passenger_Select]
	@Passenger_ID 	int = 0
,	@CTO_ID 		int
,	@ShowExcluded 	bit = 1
	
AS

select 
	p.Passenger_ID
, 	p.Contact_ID
, 	p.ContactType
, 	p.CTO_ID
,	isnull(p.PassengerNo, 0) as 'PassengerNo'
, 	p.Salutation
, 	p.FirstName
, 	p.LastName
,	p.FirstName	as 'LegalFirstName'
,	p.LastName	as 'LegalLastName'
, 	p.Birthday
	--Define a virtual column for Birthday and assign MaxDate to Null values
	--This way, when sorting, empty(null) dates will fall at the end of the list
,	IsNull(p.Birthday, dbo.f_CSC_Maximum_Date()) 	as 'SortBirthday'
	-----------------------------------------------------------------------------------------------------
, 	p.Email
, 	p.Address1
, 	p.Address2
, 	p.City
, 	p.Province
, 	p.Zip
, 	p.Country
, 	p.PhoneHome
, 	p.PhoneHomeExt
, 	p.PhoneWork
, 	p.PhoneWorkExt
,	p.ReportingPassenger
,	p.AeroplanNumber
,	p.PassportCountryCitizenship
,	p.[Document]
,	p.ExcludePassenger
, 	isnull(p.FirstName, '') + ' ' +  isnull(p.LastName, '') 	as 'PassengerName'
,	p.AutoLinkContact
,	f.FieldDisplay												as 'CitizenshipName'
,	p.Gender													as 'Gender'
,	p.MiddleName
from 	t_CT_Passenger as p
	left outer join t_CS_FieldValue as f on p.PassportCountryCitizenship = f.FieldValue and f.Lookup = 'RCLCountryCode'
where 	CTO_ID = @CTO_ID
and	(@Passenger_ID = 0 	or p.Passenger_ID = @Passenger_ID)
and	(@ShowExcluded = 1 	or isnull(p.ExcludePassenger, 0) = 0)
order by 	
	case 
		when p.ContactType = 'Main' then 1
		when p.ContactType in ('Spouse', 'Partner') then 2
		else 3
	end

GO
-----------------------------------------------------------------------------------------------------------
/****** Object:  StoredProcedure [dbo].[p_CT_Passenger_InsertUpdate]    Script Date: 08/15/2014 15:36:01 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[p_CT_Passenger_InsertUpdate]
	@Passenger_ID 				int 			= 0 output
, 	@Contact_ID 				int
, 	@ContactType 				varchar (20) 	= ''
, 	@CTO_ID 					int
,	@PassengerNo				tinyint			= 0
, 	@Salutation 				varchar (10)
, 	@FirstName 					varchar (50)
, 	@MiddleName					varchar (50)	= ''
, 	@LastName 					varchar (50)
, 	@Birthday 					smalldatetime
, 	@Email 						varchar (50)
, 	@Address1 					varchar (50)
, 	@Address2 					varchar (50)
, 	@City 						varchar (50)
, 	@Province 					varchar (25)
, 	@Zip 						varchar (50)
, 	@Country 					varchar (30)
, 	@PhoneHome 					varchar (20)
, 	@PhoneHomeExt 				varchar (15)
, 	@PhoneWork 					varchar (20)
, 	@PhoneWorkExt 				varchar (15)
,	@ReportingPassenger			bit
,	@AeroplanNumber				varchar (20)
,	@PassportCountryCitizenship varchar(50)
,	@Document					varchar(200)
,	@ExcludePassenger			bit
,	@AutoLinkContact			tinyint
,	@Gender						varchar(6)

AS
declare 	@Web_ID 			int
declare		@ContactCTOCount	int

select 	
	@Web_ID = Web_ID
from 	
	t_CT_CTO
where	
	CTO_ID = @CTO_ID

select	
	@ContactCTOCount = count(*)
from	
	t_CT_Passenger
where	
	Contact_ID = @Contact_ID
and	CTO_ID = @CTO_ID

if @ReportingPassenger = 1
	begin

	update 	t_CT_Passenger
	set	ReportingPassenger = 0
	where	CTO_ID = @CTO_ID

	end

if @Birthday = dbo.f_CSC_Minimum_Date()
	set @Birthday = null

if @Passenger_ID <=0
	begin

	-- Maintain the existing passenger
	if @ContactCTOCount > 0 and @Contact_ID > 0 
		begin
		select 
			@Passenger_ID = max(Passenger_ID)
		from	
			t_CT_Passenger
		where
			Contact_ID = @Contact_ID
		and	CTO_ID = @CTO_ID
		end
	else
		begin

		insert into t_CT_Passenger (
  	 		Contact_ID
		, 	ContactType
		, 	CTO_ID
		,	Web_ID
		,	PassengerNo
		, 	Salutation
		, 	FirstName
		,	MiddleName
		, 	LastName
		, 	Birthday
		, 	Email
		, 	Address1
		, 	Address2
		, 	City
		, 	Province
		, 	Zip
		, 	Country
		, 	PhoneHome
		, 	PhoneHomeExt
		, 	PhoneWork
		, 	PhoneWorkExt
		,	ReportingPassenger
		,	AeroplanNumber
		,	PassportCountryCitizenship
		,	[Document]
		,	ExcludePassenger
		,	AutoLinkContact
		,	Gender
		) values ( 	
			@Contact_ID
		, 	@ContactType
		, 	@CTO_ID
		,	@Web_ID
		,	@PassengerNo
		, 	@Salutation
		, 	@FirstName
		,	@MiddleName
		, 	@LastName
		, 	@Birthday
		, 	@Email
		, 	@Address1
		, 	@Address2
		, 	@City
		, 	@Province
		, 	@Zip
		, 	@Country
		, 	@PhoneHome
		, 	@PhoneHomeExt
		, 	@PhoneWork
		, 	@PhoneWorkExt
		,	@ReportingPassenger
		,	@AeroplanNumber
		,	@PassportCountryCitizenship
		,	@Document
		,	@ExcludePassenger
		,	@AutoLinkContact
		,	@Gender
		)

		/* The main contact name in the contact address of the invoice */
		if @ContactType = 'Main'
			begin

			update 	t_CT_CTOValue
			set	InvoiceFirstName = @FirstName
			,	InvoiceLastName = @LastName
			where	CTO_ID = @CTO_ID

			end

		set @Passenger_ID = @@identity

		end

	end
else
	begin

	update 	t_CT_Passenger 
	set
		Contact_ID 					= @Contact_ID
	, 	ContactType 				= @ContactType
	, 	CTO_ID 						= @CTO_ID
	,	Web_ID						= @Web_ID
	,	PassengerNo					= @PassengerNo
	, 	Salutation 					= @Salutation
	, 	FirstName 					= @FirstName
	, 	MiddleName 					= @MiddleName
	, 	LastName 					= @LastName
	, 	Birthday 					= @Birthday
	, 	Email 						= @Email
	, 	Address1 					= @Address1
	, 	Address2 					= @Address2
	, 	City 						= @City
	, 	Province 					= @Province
	, 	Zip 						= @Zip
	, 	Country 					= @Country
	, 	PhoneHome 					= @PhoneHome
	, 	PhoneHomeExt 				= @PhoneHomeExt
	, 	PhoneWork 					= @PhoneWork
	, 	PhoneWorkExt 				= @PhoneWorkExt
	,	ReportingPassenger 			= @ReportingPassenger
	,	AeroplanNumber 				= @AeroplanNumber
	,	PassportCountryCitizenship	= @PassportCountryCitizenship
	,	[Document]					= @Document
	,	ExcludePassenger			= @ExcludePassenger
	,	AutoLinkContact				= @AutoLinkContact
	,	Gender						= @Gender
	where 	Passenger_ID 			= @Passenger_ID

	end

exec p_SS_ContactValue_UpdateLoyalty_byID @AeroplanNumber
exec p_CT_Cruise_UpdateLoyalty_byID @AeroplanNumber

-- If this entry is the reporting passenger, 
-- make all other passengers for this CTO not reporting passengers
-- and update the revenue table with the passenger name
if @ReportingPassenger = 1
	begin

	update	t_CT_Revenue
	set	PassengerName = left(@LastName + ', ' + @FirstName, 50)
	where	CTO_ID = @CTO_ID

	update	t_CT_CTO
	set	Passenger_ID = @Passenger_ID
	where	CTO_ID = @CTO_ID 

	end

GO
----------------------------------------------------------------------------------------------
/****** Object:  StoredProcedure [dbo].[p_PR_Product_Select]    Script Date: 08/15/2014 15:36:53 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

----------------------------------------------------------------------------------------------      

ALTER PROCEDURE [dbo].[p_PR_Product_Select]
	@Product_ID 					int			= 0
AS
/************************************************************************************************************
************************************************************************************************************
Copyright (C) 2014 Expedia, Inc. All rights reserved. 
Description:  dbo.p_PR_Product_Select - 

Change History: 
    Date        Author          Description 
    ----------  --------------- ------------------------------------ 
    2014-03-18  Puneet Kumar    Modify to return EmbarkationPort_ID and DiembarkationPort_ID 
************************************************************************************************************
************************************************************************************************************/
DECLARE	@NoValue 					int
DECLARE	@AltDescription 			varchar(1000)
DECLARE	@EmbarkationPortPackage		bit
DECLARE	@ReturnPortPackage			bit
DECLARE @StartDuration				int
DECLARE @EndDuration				int
DECLARE @ExchangeRate				decimal(8, 4)
DECLARE @ExchangeRateDate			smalldatetime
DECLARE @EmbarkationDepartureTime	smalldatetime
DECLARE @DisembarkationArrivalTime  smalldatetime
DECLARE @CampaignEndDate			smalldatetime
DECLARE @Today						date
set @Today = convert(date, getdate(), 101)

SELECT	
	@ExchangeRate		= ExchangeRate
,	@ExchangeRateDate	= ExchangeRateDate
FROM
	t_PR_ExchangeRate
WHERE
	ExchangeRate_ID = 1

if @Product_ID > 0 
	BEGIN

	SET @NoValue		= -1
	SET @AltDescription = 'Your package includes shipboard accommodations, ocean transportation, fabulous entertainment AND daily activities, on-board meals, some beverages, AND more. It does not include air transportation, transfers, items of a personal nature such as shore excursions, specialty restaurant fees, alcoholic beverages, photographs, gratuities/service fees, taxes AND fees, medical services etc.'

	SELECT	
		@EmbarkationPortPackage = case when count(pp.PrePost_ID) > 0 then 1 else 0 end
	FROM	
		dbo.t_PR_Product					as pr
		INNER JOIN dbo.v_CC_Itinerary 		as i with (NOEXPAND, index (PK_v_CC_Itinerary))	on 	pr.Itinerary_ID = i.Itinerary_ID
		INNER JOIN dbo.t_PR_PrePost			as pp	on	i.EmbarkationPort_ID = pp.Port_ID
		INNER JOIN dbo.t_PR_PrePostDetail	as ppd	on	pp.PrePost_ID = ppd.PrePost_ID AND DateAdd(Day, -pp.Duration, pr.DepartureDate) between ppd.StartDate AND ppd.EndDate
	WHERE	
		pr.Product_ID = @Product_ID
	AND	pp.Status = 'Active'

	SELECT	
		@ReturnPortPackage = case when count(pp.PrePost_ID) > 0 then 1 else 0 end
	FROM	
		dbo.t_PR_Product					as pr
		INNER JOIN dbo.v_CC_Itinerary 		as i with (NOEXPAND, index (PK_v_CC_Itinerary))	on 	pr.Itinerary_ID = i.Itinerary_ID
		INNER JOIN dbo.t_PR_PrePost			as pp	on	i.DisembarkationPort_ID = pp.Port_ID 
		INNER JOIN dbo.t_PR_PrePostDetail	as ppd	on	pp.PrePost_ID = ppd.PrePost_ID AND DateAdd(Day, i.Duration, pr.DepartureDate) between ppd.StartDate AND ppd.EndDate
	WHERE	
		pr.Product_ID = @Product_ID
	AND	pp.Status = 'Active'

	SELECT	
		@EmbarkationDepartureTime = max(case when RowNo = 1 then DepartureTime else null end)
	,	@DisembarkationArrivalTime = max(case when RowNo = v.MaxRowNo then ArrivalTime else null end)
	FROM	
		dbo.t_CC_Itinerary as i
		INNER JOIN dbo.t_CC_ItineraryTime as t on i.ItineraryTime_ID = t.ItineraryTime_ID
		INNER JOIN dbo.t_CC_ItineraryTimeDetail as d on t.ItineraryTime_ID = d.ItineraryTime_ID
		INNER JOIN (SELECT max(RowNo) as 'MaxRowNo', ItineraryTime_ID FROM dbo.t_CC_ItineraryTimeDetail GROUP BY ItineraryTime_ID) as v on t.ItineraryTime_ID = v.ItineraryTime_ID
	WHERE
		Itinerary_ID = (
		SELECT 
			Itinerary_ID
		FROM	
			dbo.t_PR_Product
		WHERE
			Product_ID = @Product_ID)

	SELECT		@CampaignEndDate = max(ct_cp.EndDate)  --Get the latest end date
	FROM        dbo.t_CT_Campaign as ct_cp INNER JOIN
                      dbo.t_CT_CampaignDetail as ct_cpd ON ct_cp.Campaign_ID = ct_cpd.Campaign_ID
	GROUP BY	ct_cpd.Product_ID
	HAVING		ct_cpd.Product_ID = @Product_ID

	SELECT
	-- FROM the t_PR_Product table
		p.Product_ID
	,	p.Web_ID
	,	p.Itinerary_ID
	,	p.CruiseLineBrand_ID
	,	p.CruiseLine_ID
	,	c.CruiseLineCode
	,	c.SabreCode
	,	p.CruiseLineBrand
	,	p.CruiseLine
	,	p.Ship_ID
	,	p.Ship
	,	p.CalculatedStatus
	,	p.GroupNumber
	,	p.Status
	,	p.RevisedDate
	,	p.ProductSource
	,	p.ProductSourceDetail
	,	p.Currency
	,	p.DepartureDate
	,	p.HotDate
	,	p.CSCPromoCode
	,	isnull(p.PayPerPlacement, '0') as 'PayPerPlacement'
	,	p.ShowCAD
	,	p.ShowUSD
	,	p.Document_ID
	-- Originally FROM the t_PR_ProductValue table
	,	p.SpaceRecallDate
	,	p.FinalPaymentDate	
	,	p.RevisionHistory
	,	p.BookingInstruction
	,	p.BookingInstructionUS
	,	p.BookingInstructionAdmin
	,	p.GroupValue
	,	p.GroupValueShort
	,	p.GeneralInformation
	,	p.AirAddOns
	,	p.CruiseDescription
	,	p.TotalAmenityPoints
	,	p.ProductWholesaler
	,	p.AutoClose
	,	p.Deposit
	
	,	p.PriceLow
	,	CASE WHEN p.ShowCAD = 1  
			THEN CASE WHEN p.Currency = 'CAD' 
					THEN 	isnull(p.PriceLow, @NoValue)
					ELSE	cast( ceiling(isnull(p.PriceLow, @NoValue) * @ExchangeRate) as int)
				END
			ELSE	@NoValue
		END						as  'PriceLowCAD'
	,	CASE WHEN p.ShowUSD = 1  
			THEN CASE WHEN p.Currency = 'USD' 
					THEN 	isnull(p.PriceLow, @NoValue)
					ELSE 	@NoValue
				END
			ELSE	@NoValue
		END						as 'PriceLowUSD'
	
	,	p.PriceHigh
	,	CASE WHEN p.ShowCAD = 1  
			THEN CASE WHEN p.Currency = 'CAD' 
					THEN 	isnull(p.PriceHigh, @NoValue)
					ELSE 	cast( ceiling(isnull(p.PriceHigh, @NoValue) * @ExchangeRate) as int)
				END
			ELSE	@NoValue
		END						as 'PriceHighCAD'
	,	CASE WHEN p.ShowUSD = 1  
			THEN CASE WHEN p.Currency = 'USD'  
					THEN	isnull(p.PriceHigh, @NoValue)
					ELSE	@NoValue
				END
			ELSE 	@NoValue	
		END 					as 'PriceHighUSD'
	
	,	p.PortTaxes
	,	CASE WHEN p.ShowCAD = 1  
			THEN CASE WHEN p.Currency = 'CAD' 
					THEN 	isnull(p.PortTaxes, @NoValue)
					ELSE 	cast( isnull(p.PortTaxes, @NoValue) * @ExchangeRate as decimal(10,2))
				END
			ELSE	@NoValue
		END						as 'PortTaxesCAD'
	,	CASE WHEN p.ShowUSD = 1  
			THEN CASE WHEN p.Currency = 'USD' 
					THEN 	isnull(p.PortTaxes, @NoValue)
					ELSE 	@NoValue
				END
			ELSE	@NoValue
		END						as 'PortTaxesUSD'
	
	,	p.GovernmentFees
	,	CASE WHEN p.ShowCAD = 1  
			THEN CASE WHEN p.Currency = 'CAD' 
					THEN 	isnull(p.GovernmentFees, @NoValue)
					ELSE 	cast(isnull(p.GovernmentFees, @NoValue) * @ExchangeRate as decimal(10,2))
				END
			ELSE	@NoValue
		END						as 'GovernmentFeesCAD' 
	,	CASE WHEN p.ShowUSD = 1  
			THEN CASE WHEN p.Currency = 'USD' 
					THEN 	isnull(p.GovernmentFees, @NoValue)
					ELSE 	@NoValue
				END
			ELSE	@NoValue
		END						as 'GovernmentFeesUSD'

	,	p.FuelSurcharge
	,	CASE WHEN p.ShowCAD = 1  
			THEN CASE WHEN p.Currency = 'CAD' 
					THEN 	isnull(p.FuelSurcharge, @NoValue)
					ELSE 	cast(isnull(p.FuelSurcharge, @NoValue) * @ExchangeRate as decimal(10,2))
				END
			ELSE	@NoValue
		END						as 'FuelSurchargeCAD' 
	,	CASE WHEN p.ShowUSD = 1  
			THEN CASE WHEN p.Currency = 'USD' 
					THEN 	isnull(p.FuelSurcharge, @NoValue)
					ELSE 	@NoValue
				END
			ELSE	@NoValue
		END						as 'FuelSurchargeUSD'
	
	-- FROM the t_CC_Ship table
	,	s.ShipClass_ID
	,	s.ShipCode
	
	-- FROM the t_CC_CruiseLine table
	,	c.CruiseLineCode
	
	-- FROM the t_CC_Itinerary table
	,	i.Destination
	,	i.SubDestination
	,	i.EmbarkationPort
	,	i.DisembarkationPort 	as 'ReturnPort'
	,	@EmbarkationPortPackage	as 'EmbarkationPortPackage'
	,	@ReturnPortPackage		as 'ReturnPortPackage'
	,	i.Duration
	,	i.Itinerary
	,	isnull(i.IsCruiseTour, 0) as 'IsCruiseTour'

	,	ep.AirportCode 			as 'EmbarkationAirportCode'
	,	dp.AirportCode 			as 'DisembarkationAirportCode'
	,	isnull(fCAD.GroupCAD_Product_ID, fUSD.GroupCAD_Product_ID) as 'GroupCAD_Product_ID'
	,	isnull(fCAD.GroupUSD_Product_ID, fUSD.GroupUSD_Product_ID) as 'GroupUSD_Product_ID'
	,	p.FITBonusCommPer
	,	p.FITBonusType
	,	p.FITBonusAmt
	,	p.FITBonusType2
	,	p.ActivityDate
	,	p.SabreSailID
	
	,	CASE WHEN c.BookCD = 1
					AND not (c.CruiseLineCode = 'PCL' AND isnull(p.ProductSourceDetail, '') = 'Non Multi-Agency') 
					AND (p.ProductSource like '%FIT%' or (p.ProductSource = 'Top 100' AND c.CruiseLineCode in ('PCL','HAL','CUN')))
					AND i.Destination <> 'World Cruises'
					AND (isnull(c.BookCheckSailID, 0) = 0 or isnull(c.BookCheckSailID, 0) = 1 AND isnull(p.SabreSailID, '') <> '')
			THEN 1
			ELSE 0
		END												as 'BookableOnlineCD'

	,	CASE WHEN c.BookCSC = 1
					AND not (c.CruiseLineCode = 'PCL' AND isnull(p.ProductSourceDetail, '') = 'Non Multi-Agency') 
					AND (p.ProductSource like '%FIT%' or (p.ProductSource = 'Top 100' AND c.CruiseLineCode in ('PCL','HAL','CUN')))
					AND i.Destination <> 'World Cruises'
					AND (isnull(c.BookCheckSailID, 0) = 0 or isnull(c.BookCheckSailID, 0) = 1 AND isnull(p.SabreSailID, '') <> '')
			THEN 1
			ELSE 0
		END												as 'BookableOnlineCSC'
	,	@EmbarkationDepartureTime						as 'EmbarkationDepartureTime'
	,	@DisembarkationArrivalTime						as 'DisembarkationArrivalTime'
	,	cp.advertised									as 'Advertised'
	,	@CampaignEndDate								as 'CampaignEndDate'
	,	i.EmbarkationPort_ID
	,	i.DisembarkationPort_ID
	
	FROM 	
		dbo.t_PR_Product 						as p
		left outer join dbo.t_CC_ExchangeRate 	as e 	on 	p.Cruiseline_ID = e.Cruiseline_ID AND dbo.f_DisplayYearMonth(p.DepartureDate) = dbo.f_DisplayYearMonth(e.ExchangeDate)
		INNER JOIN dbo.t_CC_Ship 				as s 	on 	p.Ship_ID = s.Ship_ID	
		INNER JOIN dbo.t_CC_CruiseLineBrand		as c 	on 	p.CruiseLineBrand_ID = c.CruiseLineBrand_ID	
		left outer join dbo.v_CC_Itinerary 		as i with (NOEXPAND, index (PK_v_CC_Itinerary))	on 	p.Itinerary_ID = i.Itinerary_ID
		left outer join dbo.t_CC_Port			as ep	on	i.EmbarkationPort_ID = ep.Port_ID
		left outer join dbo.t_CC_Port			as dp	on	i.DisembarkationPort_ID = dp.Port_ID
		left outer join dbo.t_PR_GroupFIT		as fCAD	on	p.Product_ID = fCAD.FIT_CAD_Product_ID
		left outer join dbo.t_PR_GroupFIT		as fUSD	on	p.Product_ID = fUSD.FIT_USD_Product_ID
		left outer join 
			(
				Select 
					Product_ID, 
					Cast(MAX(list) as varchar(130)) as 'advertised' 
				FROM 
					(
						Select 
							x.Product_ID,	
							REPLACE('##' +(Select ',' + cp1.CampaignSubType 
											FROM dbo.t_CT_Campaign as cp1			
											INNER JOIN dbo.t_CT_CampaignDetail as cpd on cp1.Campaign_ID = cpd.Campaign_ID 
											WHERE cpd.Product_ID = x.Product_ID 
											AND cp1.CampaignSubType is not null 
											AND cp1.CampaignSubType <> '' 
											AND cp1.EndDate >= @Today 
											Group by cp1.CampaignSubType for xml  path('')), '##,', '') as 'list' 
						FROM dbo.t_CT_CampaignDetail as x) as v
						WHERE v.Product_ID is not null 
						AND v.list is not null
						Group by Product_ID) as cp on p.Product_ID = cp.Product_ID
	WHERE	 
		p.Product_ID = @Product_ID
	
	END

--------------------------------------------------------------------- 
-- Unit Test 
--------------------------------------------------------------------- 
/******************************************************************** 
DECLARE
	@StartDate				DATETIME = CURRENT_TIMESTAMP
;
EXEC dbo.p_PR_Product_Select 
   	   @Product_ID  = 0 --   235050

;
SELECT DATEDIFF(ms,@StartDate, CURRENT_TIMESTAMP) AS ElapsedTime
;
*/ 


GO
-------------------------------------------------------------------------------------------
/****** Object:  StoredProcedure [dbo].[p_PR_ProductPicture_Select]    Script Date: 08/15/2014 15:42:14 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


ALTER PROCEDURE [dbo].[p_PR_ProductPicture_Select]
	@Product_ID 	int
,	@Web_ID			int				= 0
,	@CultureName 	varchar(10) 	= 'en-CA'
,	@RateType		varchar(30)		= ''
AS
/************************************************************************************************************
************************************************************************************************************
Copyright (C) 2014 Expedia, Inc. All rights reserved. 
Description:  dbo.p_PR_ProductPicture_Select - 

Change History: 
    Date        Author          Description 
    ----------  --------------- ------------------------------------ 
	2014-03-14  Puneet Kumar	Implementing NOLOCK hint to resolve blocking issues 
	2014-03-18  Puneet Kumar    Modify to return EmbarkationPort_ID and DiembarkationPort_ID
************************************************************************************************************
************************************************************************************************************/

declare @NoValue 				int
declare	@AmenityOffer 			varchar(150)
declare	@Count 					int
declare	@EmbarkationPortPackage	bit
declare	@ReturnPortPackage		bit
declare @ExchangeRate			decimal(8, 4)
declare @ExchangeRateDate		smalldatetime
declare @EmbarkationDepartureTime	smalldatetime
declare @DisembarkationArrivalTime  smalldatetime

SELECT	
	@ExchangeRate		= ExchangeRate
,	@ExchangeRateDate	= ExchangeRateDate
FROM
	dbo.t_PR_ExchangeRate WITH (NOLOCK)
WHERE
	ExchangeRate_ID = 1
;
set @NoValue		= -1
;
if @CultureName = ''
	set @CultureName = 'en-CA'
;
if @CultureName <>  'en-CA'
	SELECT 	
		@AmenityOffer  = l.[Text]
	FROM 	
		dbo.t_CC_LanguageSource 				as ls  WITH (NOLOCK)
		INNER JOIN t_CC_LanguageTextUsage	as lu  WITH (NOLOCK)	on ls.LanguageSource_ID = lu.LanguageSource_ID
		INNER JOIN t_CC_LanguageText		as l   WITH (NOLOCK) 	on lu.Language_ID = l.Language_ID
	WHERE 	
		ls.FieldName = 'AmenityOffer'
	AND l.CultureName = @CultureName	
;
SELECT 
	@Count = count(*) 
FROM 
	dbo.t_CS_LocalSpecial  WITH (NOLOCK)
WHERE 	
	Product_ID = @Product_ID 
AND Web_ID = @Web_ID
AND SpecialType = 'Local'	
;
SELECT	
	@EmbarkationPortPackage = CASE WHEN count(pp.PrePost_ID) > 0 THEN 1 ELSE 0 end
FROM
	dbo.t_PR_ProductPicture				as pr WITH (NOLOCK)
	INNER JOIN dbo.v_CC_Itinerary 		as i with (NOEXPAND, index (PK_v_CC_Itinerary))	on pr.Itinerary_ID = i.Itinerary_ID
	INNER JOIN dbo.t_PR_PrePost			as pp WITH (NOLOCK)	on	i.EmbarkationPort_ID = pp.Port_ID
	INNER JOIN dbo.t_PR_PrePostDetail	as ppd	WITH (NOLOCK) on	pp.PrePost_ID = ppd.PrePost_ID AND DateAdd(Day, -pp.Duration, pr.DepartureDate) between ppd.StartDate AND ppd.EndDate
WHERE	
	pr.Product_ID = @Product_ID
;
SELECT	
	@ReturnPortPackage = CASE WHEN count(pp.PrePost_ID) > 0 THEN 1 ELSE 0 end
FROM	
	dbo.t_PR_ProductPicture				as pr WITH (NOLOCK)
	INNER JOIN dbo.v_CC_Itinerary		as i with (NOEXPAND, index (PK_v_CC_Itinerary))	on pr.Itinerary_ID = i.Itinerary_ID
	INNER JOIN dbo.t_PR_PrePost			as pp  WITH (NOLOCK)	on	i.DisembarkationPort_ID = pp.Port_ID
	INNER JOIN dbo.t_PR_PrePostDetail	as ppd  WITH (NOLOCK)	on	pp.PrePost_ID = ppd.PrePost_ID AND DateAdd(Day, i.Duration, pr.DepartureDate) between ppd.StartDate AND ppd.EndDate
WHERE	
	pr.Product_ID = @Product_ID
;
SELECT	
	@EmbarkationDepartureTime = max(CASE WHEN RowNo = 1 THEN DepartureTime ELSE null end)
,	@DisembarkationArrivalTime = max(CASE WHEN RowNo = v.MaxRowNo THEN ArrivalTime ELSE null end)
FROM	
	t_CC_Itinerary as i WITH (NOLOCK)
	INNER JOIN dbo.t_CC_ItineraryTime as t  WITH (NOLOCK) on i.ItineraryTime_ID = t.ItineraryTime_ID
	INNER JOIN dbo.t_CC_ItineraryTimeDetail as d  WITH (NOLOCK) on t.ItineraryTime_ID = d.ItineraryTime_ID
	INNER JOIN (SELECT max(RowNo) as 'MaxRowNo', ItineraryTime_ID FROM dbo.t_CC_ItineraryTimeDetail  WITH (NOLOCK) GROUP BY ItineraryTime_ID) as v on t.ItineraryTime_ID = v.ItineraryTime_ID
WHERE
	Itinerary_ID = (
	SELECT 
		Itinerary_ID
	FROM	
		dbo.t_PR_Product  WITH (NOLOCK)
	WHERE
		Product_ID = @Product_ID)
;
SELECT
-- FROM the t_PR_Product table
	p.Product_ID
,	p.Web_ID

,	p.Itinerary_ID
,	p.DepartureDate

,	p.CruiseLineBrand_ID
,	p.CruiseLine_ID
,	p.CruiseLineBrand
,	p.CruiseLine
,	p.CruiselineImage_ID
,	p.CruiselineImageType
,	p.CruiselineImageExtension

,	p.Ship_ID
,	p.Ship

,	p.CalculatedStatus
,	p.Status

,	p.ProductSource
,	p.ProductSourceDetail
,	p.GroupNumber
,	CASE WHEN @CultureName <> 'en-CA' AND isnull( p.GroupValue,'') <> '' 
		THEN isnull(@AmenityOffer, p.GroupValue)
		ELSE p.GroupValue
	end 											as 'GroupValue'
,	p.GroupValueShort

,	p.Currency
,	p.ShowCAD
,	p.ShowUSD

,	p.GovernmentFees
,	p.GovernmentFeesCAD
,	p.GovernmentFeesUSD
,	CASE WHEN p.GovernmentFeesUSD < 987654321 THEN p.GovernmentFeesUSD * @ExchangeRate ELSE p.GovernmentFeesUSD end	as 'GovernmentFeesCADExch'

,	p.FuelSurcharge
,	p.FuelSurchargeCAD
,	p.FuelSurchargeUSD
,	CASE WHEN p.FuelSurchargeUSD < 987654321 THEN p.FuelSurchargeUSD * @ExchangeRate ELSE p.FuelSurchargeUSD end	as 'FuelSurchargeCADExch'

,	p.PortTaxes
,	p.PortTaxesCAD
,	p.PortTaxesUSD
,	CASE WHEN p.PortTaxesUSD < 987654321 THEN p.PortTaxesUSD * @ExchangeRate ELSE p.PortTaxesUSD end				as 'PortTaxesCADExch'
-- id Product Marked as Local Special
,	CASE WHEN @Count > 0 
		THEN 1
		ELSE 0
	end												as 'IsLocalSpecial'

-- sell sheet values
,	p.PriceInterior
,	p.PriceOceanView
,	p.PriceBalcony
,	p.PriceSuite

,	p.CategoryInteriorCode
,	p.CategoryOceanviewCode
,	p.CategoryBalconyCode
,	p.CategorySuiteCode

,	CASE WHEN p.OurPrice <> 987654321 
		THEN p.OurPrice 
		ELSE @NoValue 
	end 											as 'OurPrice'
,	CASE WHEN p.OurPriceCAD <> 987654321 
		THEN p.OurPriceCAD
		ELSE @NoValue 
	end 											as 'OurPriceCAD'
,	CASE WHEN p.OurPriceUSD <> 987654321 
		THEN p.OurPriceUSD
		ELSE @NoValue 
	end 											as 'OurPriceUSD'
,	CASE WHEN p.OurPriceUSD <> 987654321 
		THEN ceiling(p.OurPriceUSD * @ExchangeRate)
		ELSE @NoValue 
	end 											as 'OurPriceCADExch'

,	CASE WHEN p.PriceInteriorCAD <> 987654321 
		THEN p.PriceInteriorCAD	
		ELSE @NoValue 
	end 											as 'PriceInteriorCAD'
,	CASE WHEN p.PriceInteriorUSD <> 987654321 
		THEN p.PriceInteriorUSD
		ELSE @NoValue 
	end 											as 'PriceInteriorUSD'
,	CASE WHEN p.PriceInteriorUSD <> 987654321 
		THEN ceiling(p.PriceInteriorUSD * @ExchangeRate)
		ELSE @NoValue 
	end 											as 'PriceInteriorCADExch'

,	CASE WHEN p.PriceOceanviewCAD <> 987654321 
		THEN p.PriceOceanviewCAD
		ELSE @NoValue 
	end 											as 'PriceOceanviewCAD'
,	CASE WHEN p.PriceOceanviewUSD <> 987654321 
		THEN p.PriceOceanviewUSD
		ELSE @NoValue 
	end 											as 'PriceOceanviewUSD'
,	CASE WHEN p.PriceOceanviewUSD <> 987654321 
		THEN ceiling(p.PriceOceanviewUSD * @ExchangeRate)
		ELSE @NoValue 
	end 											as 'PriceOceanviewCADExch'

,	CASE WHEN p.PriceBalconyCAD <> 987654321 
		THEN p.PriceBalconyCAD
		ELSE @NoValue 
	end 											as 'PriceBalconyCAD'
,	CASE WHEN p.PriceBalconyUSD <> 987654321 
		THEN p.PriceBalconyUSD
		ELSE @NoValue 
	end 											as 'PriceBalconyUSD'
,	CASE WHEN p.PriceBalconyUSD <> 987654321 
		THEN ceiling(p.PriceBalconyUSD * @ExchangeRate)
		ELSE @NoValue 
	end 											as 'PriceBalconyCADExch'

,	CASE WHEN p.PriceSuiteCAD <> 987654321 
		THEN p.PriceSuiteCAD
		ELSE @NoValue 
	end 											as 'PriceSuiteCAD'
,	CASE WHEN p.PriceSuiteUSD <> 987654321 
		THEN p.PriceSuiteUSD
		ELSE @NoValue 	
	end 											as 'PriceSuiteUSD'
,	CASE WHEN p.PriceSuiteUSD <> 987654321 
		THEN ceiling(p.PriceSuiteUSD * @ExchangeRate)
		ELSE @NoValue 	
	end 											as 'PriceSuiteCADExch'

,	p.Restriction
,	p.RestrictionInside
,	p.RestrictionOceanview
,	p.RestrictionBalcony
,	p.RestrictionSuite

-- FROM the t_CC_Ship table
,	s.ShipClass_ID
,	s.ShipCode

-- FROM the t_CC_CruiseLine table
,	c.CruiseLineCode
,	c.SabreCode
,	CASE WHEN @CultureName = 'en-CA' THEN 
		CASE WHEN isnull(p.CruiseDescription, '') = '' THEN c.TranslatedDescription ELSE isnull(p.CruiseDescription, '') end
	ELSE c.TranslatedDescription  end as 'CruiseDescription'

-- FROM the t_CC_Itinerary table
,	CASE WHEN isnull(ff.TranslatedFieldValue, '') = '' 
		THEN p.Destination 
		ELSE ff.TranslatedFieldValue  
	end 											as 'Destination'
,	CASE WHEN isnull(fs.TranslatedFieldValue, '') = '' 
		THEN p.Subdestination 
		ELSE fs.TranslatedFieldValue 
	end 											as 'Subdestination'

----------------
,	e.TranslatedPortName							as 'EmbarkationPort'
,	d.TranslatedPortName							as 'ReturnPort'
,	@EmbarkationPortPackage							as 'EmbarkationPortPackage'
,	@ReturnPortPackage								as 'ReturnPortPackage'
,	p.Duration
,	p.Itinerary
,	p.Deposit

,	isnull(fc.GroupCAD_Product_ID, fu.GroupCAD_Product_ID) as 'GroupCAD_Product_ID'
,	isnull(fc.GroupUSD_Product_ID, fu.GroupUSD_Product_ID) as 'GroupUSD_Product_ID'

,	p.TotalAmenityPoints
,	c.TranslatedFuelDisclaimer							as 'Disclaimer'

,	p.SabreSailID
,	p.SabreDestinationCode
,	p.isCruiseTour
,	p.ActivityDate
,	p.CSCPromoCode
,	p.BookableOnlineCSC
,	p.BookableOnlineCD
,	isnull(p.BookUSOnly, 0)								as 'BookUSOnly'
,	p.OnlineSource
,	p.SabreAPIEnabled

,	@EmbarkationDepartureTime						as 'EmbarkationDepartureTime'
,	@DisembarkationArrivalTime						as 'DisembarkationArrivalTime'
,	p.PayPerPlacement
,	p.isShowFrenchInfoCruiseLine
,	p.DisableShipPhoto
,	p.isShowFrenchInfoShip
,	r.TotalReviews
,	r.AverageOverallRate
,       p.EmbarkationPort_ID
,       p.DisembarkationPort_ID
FROM 	
	dbo.t_PR_ProductPicture 													as p WITH (NOLOCK)
	INNER JOIN dbo.t_CC_Ship 													as s WITH (NOLOCK)	on p.Ship_ID = s.Ship_ID	
	INNER JOIN dbo.f_CC_CruiselineBrand(@CultureName)							as c 	on p.CruiseLineBrand_ID = c.CruiseLineBrand_ID	
	INNER JOIN dbo.f_CC_Port(@CultureName)										as e 	on p.EmbarkationPort_ID = e.Port_ID
	INNER JOIN dbo.f_CC_Port(@CultureName)										as d 	on p.DisembarkationPort_ID = d.Port_ID
	left outer join dbo.f_CS_FieldValue(@CultureName, 'ProductDestination')		as ff 	on p.Destination = ff.FieldValue
	left outer join dbo.f_CS_FieldValue(@CultureName, 'ProductSubDestination')	as fs 	on p.SubDestination = fs.FieldValue
	left outer join dbo.t_PR_GroupFIT											as fc  WITH (NOLOCK)	on p.Product_ID = fc.FIT_CAD_Product_ID
	left outer join dbo.t_PR_GroupFIT											as fu  WITH (NOLOCK)	on p.Product_ID = fu.FIT_USD_Product_ID
	left outer join
	(Select Ship, TotalReviews, AverageOverallRate 
	FROM Report.dbo.t_PR_ReviewShipAverage  WITH (NOLOCK) WHERE Culture = @CultureName)	as r	on CAST(p.Ship_ID as Varchar(50)) = r.Ship
WHERE	 
	p.Product_ID = @Product_ID
;


--------------------------------------------------------------------- 
-- Unit Test 
--------------------------------------------------------------------- 
/******************************************************************** 
DECLARE
	@StartDate				DATETIME = CURRENT_TIMESTAMP
;
EXEC dbo.p_PR_ProductPicture_Select 
   	   @Product_ID  =  0  --  235050
	 , @Web_ID       = 0  --   1
         , @CultureName = 'en-CA'
         , @RateType	= ''

;
SELECT DATEDIFF(ms,@StartDate, CURRENT_TIMESTAMP) AS ElapsedTime
;
*/ 



