DROP PROCEDURE [dbo].[p_AD_Page_Update_PageNotes]
GO


