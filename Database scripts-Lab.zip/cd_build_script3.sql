/****** Object:  StoredProcedure [dbo].[p_AD_Page_Select]    Script Date: 06/27/2014 11:34:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER PROCEDURE [dbo].[p_AD_Page_Select] 
	@Project_ID 	int
,	@StartDate		smalldatetime
,	@EndDate		smalldatetime

AS

select	
	p.Page_ID
,	p.Project_ID
,	p.PageName
,	p.MenuName
,	p.PageNotes
,	isnull(v.MenuTitle, '')							as 'MenuTitle'
,	cast(isnull(pv.PageHits, 0) as varchar(max))	as 'PageHits'
from	
	t_AD_Page as p
	left outer join (
		select	
			Page_ID
		,	max(MenuTitle) as 'MenuTitle'
		from	t_AD_CDMenu
		group by 
			Page_ID) as v on p.Page_ID = v.Page_ID
	left outer join (
		select	
			Page_ID
		,	count(*) as 'PageHits'
		from	t_AD_PageView
		where
			ViewDate between @StartDate and @EndDate
		group by
			Page_ID) as pv on p.Page_ID = pv.Page_ID
where
	p.Project_ID = @Project_ID
and	p.DateDeleted is null
order by
	p.PageName
GO
-------------------------------------------------------------------------------------
/****** Object:  StoredProcedure [dbo].[p_AD_RoleWeb_SelectAccess]    Script Date: 06/23/2014 15:47:12 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER PROCEDURE [dbo].[p_AD_RoleWeb_SelectAccess] --1967
	@ProjectName	varchar(50)
,	@PageName		varchar(50)
,	@SectionName	varchar(100)
, 	@Web_ID 		int

AS


if @PageName = '' and @SectionName = ''

	select
		COUNT(pr.Project_ID) as 'Access'
	,	''					 as 'MenuName'
	from
		t_AD_Project as pr
	where 
		pr.ProjectName = @ProjectName
	and	pr.Project_ID in	(
							select	rpr.Project_ID  
							from	t_AD_RoleProject		as rpr
									inner join t_AD_RoleWeb as rw	on rpr.Role_ID = rw.Role_ID 
							where	rw.Web_ID = @Web_ID

							union

							select	Project_ID  
							from	t_AD_WebProject 
							where	Web_ID = @Web_ID
							)	
      
if @PageName <> '' and @SectionName = ''
	begin
	
	select
		COUNT(pa.Page_ID)		as 'Access'
	,	MAX(MenuName)			as 'MenuName'
	from  
		t_AD_Project			as pr 
		inner join t_AD_Page	as pa	on pr.Project_ID = pa.Project_ID
	where 
		pr.ProjectName = @ProjectName
	and	pa.PageName = @PageName
	and pa.Page_ID in	(
						select	rpa.Page_ID  
						from	t_AD_RolePage			as rpa
								inner join t_AD_RoleWeb as rw	on rpa.Role_ID = rw.Role_ID 
						where	rw.Web_ID = @Web_ID
						
						union
						
						select	Page_ID  
						from	t_AD_WebPage 
						where	Web_ID = @Web_ID
						) 
						
	insert into t_AD_PageView (
		Page_ID 
	,	Web_ID
	,	ViewDate)
	select
		pa.Page_ID
	,	@Web_ID
	,	GetDate()
	from
		t_AD_Project			as pr 
		inner join t_AD_Page	as pa	on pr.Project_ID = pa.Project_ID
	where
		pr.ProjectName = @ProjectName
	and	pa.PageName = @PageName
	
	end												
if @PageName <> '' and @SectionName <> ''

	select
		COUNT(se.Section_ID)	as 'Access'
	,	''						as 'MenuName'
	from  
		t_AD_Project			as pr 
		inner join t_AD_Page	as pa	on pr.Project_ID = pa.Project_ID 
		inner join t_AD_Section as se	on pa.Page_ID = se.Page_ID
	where 
		pr.ProjectName = @ProjectName
	and	pa.PageName = @PageName
	and se.SectionName = @SectionName
	and se.Section_ID in	(
							select	rse.Section_ID  
							from	t_AD_RoleSection			as rse
									inner join t_AD_RoleWeb		as rw	on rse.Role_ID = rw.Role_ID 
							where	rw.Web_ID = @Web_ID
							
							union
							
							select	Section_ID  
							from	t_AD_WebSection 
							where Web_ID = @Web_ID
							)
GO
--------------------------------------------------------------------------------------
----------------------------------------------------  
/****** Script for SelectTopNRows command from SSMS  ******/
--------------------------------------------------------------------------------------------------------------
/****** Object:  StoredProcedure [dbo].[p_PR_Product_Select]    Script Date: 08/08/2014 12:26:39 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[p_PR_Product_Select]
	@Product_ID 					int			= 0
as
declare	@NoValue 					int
declare	@AltDescription 			varchar(1000)
declare	@EmbarkationPortPackage		bit
declare	@ReturnPortPackage			bit
declare @StartDuration				int
declare @EndDuration				int
declare @ExchangeRate				decimal(8, 4)
declare @ExchangeRateDate			smalldatetime
declare @EmbarkationDepartureTime	smalldatetime
declare @DisembarkationArrivalTime  smalldatetime
declare @CampaignEndDate			smalldatetime
declare @Today						date
set @Today = convert(date, getdate(), 101)

select	
	@ExchangeRate		= ExchangeRate
,	@ExchangeRateDate	= ExchangeRateDate
from
	t_PR_ExchangeRate
where
	ExchangeRate_ID = 1

if @Product_ID > 0 
	begin

	set @NoValue		= -1
	set @AltDescription = 'Your package includes shipboard accommodations, ocean transportation, fabulous entertainment and daily activities, on-board meals, some beverages, and more. It does not include air transportation, transfers, items of a personal nature such as shore excursions, specialty restaurant fees, alcoholic beverages, photographs, gratuities/service fees, taxes and fees, medical services etc.'

	select	
		@EmbarkationPortPackage = case when count(pp.PrePost_ID) > 0 then 1 else 0 end
	from	
		t_PR_Product					as pr
		inner join v_CC_Itinerary 		as i with (NOEXPAND, index (PK_v_CC_Itinerary))	on 	pr.Itinerary_ID = i.Itinerary_ID
		inner join t_PR_PrePost			as pp	on	i.EmbarkationPort_ID = pp.Port_ID
		inner join t_PR_PrePostDetail	as ppd	on	pp.PrePost_ID = ppd.PrePost_ID and DateAdd(Day, -pp.Duration, pr.DepartureDate) between ppd.StartDate and ppd.EndDate
	where	
		pr.Product_ID = @Product_ID
	and	pp.Status = 'Active'

	select	
		@ReturnPortPackage = case when count(pp.PrePost_ID) > 0 then 1 else 0 end
	from	
		t_PR_Product					as pr
		inner join v_CC_Itinerary 		as i with (NOEXPAND, index (PK_v_CC_Itinerary))	on 	pr.Itinerary_ID = i.Itinerary_ID
		inner join t_PR_PrePost			as pp	on	i.DisembarkationPort_ID = pp.Port_ID 
		inner join t_PR_PrePostDetail	as ppd	on	pp.PrePost_ID = ppd.PrePost_ID and DateAdd(Day, i.Duration, pr.DepartureDate) between ppd.StartDate and ppd.EndDate
	where	
		pr.Product_ID = @Product_ID
	and	pp.Status = 'Active'

	select	
		@EmbarkationDepartureTime = max(case when RowNo = 1 then DepartureTime else null end)
	,	@DisembarkationArrivalTime = max(case when RowNo = v.MaxRowNo then ArrivalTime else null end)
	from	
		t_CC_Itinerary as i
		inner join t_CC_ItineraryTime as t on i.ItineraryTime_ID = t.ItineraryTime_ID
		inner join t_CC_ItineraryTimeDetail as d on t.ItineraryTime_ID = d.ItineraryTime_ID
		inner join (select max(RowNo) as 'MaxRowNo', ItineraryTime_ID from t_CC_ItineraryTimeDetail group by ItineraryTime_ID) as v on t.ItineraryTime_ID = v.ItineraryTime_ID
	where
		Itinerary_ID = (
		select 
			Itinerary_ID
		from	
			t_PR_Product
		where
			Product_ID = @Product_ID)

	select		@CampaignEndDate = max(ct_cp.EndDate)  --Get the latest end date
	from        t_CT_Campaign as ct_cp INNER JOIN
                      t_CT_CampaignDetail as ct_cpd ON ct_cp.Campaign_ID = ct_cpd.Campaign_ID
	group by	ct_cpd.Product_ID
	having		ct_cpd.Product_ID = @Product_ID

	select
	-- from the t_PR_Product table
		p.Product_ID
	,	p.Web_ID
	,	p.Itinerary_ID
	,	p.CruiseLineBrand_ID
	,	p.CruiseLine_ID
	,	c.CruiseLineCode
	,	c.SabreCode
	,	p.CruiseLineBrand
	,	p.CruiseLine
	,	p.Ship_ID
	,	p.Ship
	,	p.CalculatedStatus
	,	p.GroupNumber
	,	p.Status
	,	p.RevisedDate
	,	p.ProductSource
	,	p.ProductSourceDetail
	,	p.Currency
	,	p.DepartureDate
	,	p.HotDate
	,	p.CSCPromoCode
	,	isnull(p.PayPerPlacement, '0') as 'PayPerPlacement'
	,	p.ShowCAD
	,	p.ShowUSD
	,	p.Document_ID
	-- Originally from the t_PR_ProductValue table
	,	p.SpaceRecallDate
	,	p.FinalPaymentDate	
	,	p.RevisionHistory
	,	p.BookingInstruction
	,	p.BookingInstructionUS
	,	p.BookingInstructionAdmin
	,	p.GroupValue
	,	p.GroupValueShort
	,	p.GeneralInformation
	,	p.AirAddOns
	,	p.CruiseDescription
	,	p.TotalAmenityPoints
	,	p.ProductWholesaler
	,	p.AutoClose
	,	p.Deposit
	
	,	p.PriceLow
	,	case when p.ShowCAD = 1  
			then case when p.Currency = 'CAD' 
					then 	isnull(p.PriceLow, @NoValue)
					else	cast( ceiling(isnull(p.PriceLow, @NoValue) * @ExchangeRate) as int)
				end
			else	@NoValue
		end						as  'PriceLowCAD'
	,	case when p.ShowUSD = 1  
			then case when p.Currency = 'USD' 
					then 	isnull(p.PriceLow, @NoValue)
					else 	@NoValue
				end
			else	@NoValue
		end						as 'PriceLowUSD'
	
	,	p.PriceHigh
	,	case when p.ShowCAD = 1  
			then case when p.Currency = 'CAD' 
					then 	isnull(p.PriceHigh, @NoValue)
					else 	cast( ceiling(isnull(p.PriceHigh, @NoValue) * @ExchangeRate) as int)
				end
			else	@NoValue
		end						as 'PriceHighCAD'
	,	case when p.ShowUSD = 1  
			then case when p.Currency = 'USD'  
					then	isnull(p.PriceHigh, @NoValue)
					else	@NoValue
				end
			else 	@NoValue	
		end 					as 'PriceHighUSD'
	
	,	p.PortTaxes
	,	case when p.ShowCAD = 1  
			then case when p.Currency = 'CAD' 
					then 	isnull(p.PortTaxes, @NoValue)
					else 	cast( isnull(p.PortTaxes, @NoValue) * @ExchangeRate as decimal(10,2))
				end
			else	@NoValue
		end						as 'PortTaxesCAD'
	,	case when p.ShowUSD = 1  
			then case when p.Currency = 'USD' 
					then 	isnull(p.PortTaxes, @NoValue)
					else 	@NoValue
				end
			else	@NoValue
		end						as 'PortTaxesUSD'
	
	,	p.GovernmentFees
	,	case when p.ShowCAD = 1  
			then case when p.Currency = 'CAD' 
					then 	isnull(p.GovernmentFees, @NoValue)
					else 	cast(isnull(p.GovernmentFees, @NoValue) * @ExchangeRate as decimal(10,2))
				end
			else	@NoValue
		end						as 'GovernmentFeesCAD' 
	,	case when p.ShowUSD = 1  
			then case when p.Currency = 'USD' 
					then 	isnull(p.GovernmentFees, @NoValue)
					else 	@NoValue
				end
			else	@NoValue
		end						as 'GovernmentFeesUSD'

	,	p.FuelSurcharge
	,	case when p.ShowCAD = 1  
			then case when p.Currency = 'CAD' 
					then 	isnull(p.FuelSurcharge, @NoValue)
					else 	cast(isnull(p.FuelSurcharge, @NoValue) * @ExchangeRate as decimal(10,2))
				end
			else	@NoValue
		end						as 'FuelSurchargeCAD' 
	,	case when p.ShowUSD = 1  
			then case when p.Currency = 'USD' 
					then 	isnull(p.FuelSurcharge, @NoValue)
					else 	@NoValue
				end
			else	@NoValue
		end						as 'FuelSurchargeUSD'
	
	-- from the t_CC_Ship table
	,	s.ShipClass_ID
	,	s.ShipCode
	,	s.SabreShipCode
	
	-- from the t_CC_CruiseLine table
	,	c.CruiseLineCode
	
	-- from the t_CC_Itinerary table
	,	i.Destination
	,	i.SubDestination
	,	i.EmbarkationPort
	,	i.DisembarkationPort 	as 'ReturnPort'
	,	@EmbarkationPortPackage	as 'EmbarkationPortPackage'
	,	@ReturnPortPackage		as 'ReturnPortPackage'
	,	i.Duration
	,	i.Itinerary
	,	isnull(i.IsCruiseTour, 0) as 'IsCruiseTour'

	,	ep.AirportCode 			as 'EmbarkationAirportCode'
	,	dp.AirportCode 			as 'DisembarkationAirportCode'
	,	isnull(fCAD.GroupCAD_Product_ID, fUSD.GroupCAD_Product_ID) as 'GroupCAD_Product_ID'
	,	isnull(fCAD.GroupUSD_Product_ID, fUSD.GroupUSD_Product_ID) as 'GroupUSD_Product_ID'
	,	p.FITBonusCommPer
	,	p.FITBonusType
	,	p.FITBonusAmt
	,	p.FITBonusType2
	,	p.ActivityDate
	,	p.SabreSailID
	
	,	case when c.BookCD = 1
					and not (c.CruiseLineCode = 'PCL' and isnull(p.ProductSourceDetail, '') = 'Non Multi-Agency') 
					and (p.ProductSource like '%FIT%' or (p.ProductSource = 'Top 100' and c.CruiseLineCode in ('PCL','HAL','CUN')))
					and i.Destination <> 'World Cruises'
					and (isnull(c.BookCheckSailID, 0) = 0 or isnull(c.BookCheckSailID, 0) = 1 and isnull(p.SabreSailID, '') <> '')
			then 1
			else 0
		end												as 'BookableOnlineCD'

	,	case when c.BookCSC = 1
					and not (c.CruiseLineCode = 'PCL' and isnull(p.ProductSourceDetail, '') = 'Non Multi-Agency') 
					and (p.ProductSource like '%FIT%' or (p.ProductSource = 'Top 100' and c.CruiseLineCode in ('PCL','HAL','CUN')))
					and i.Destination <> 'World Cruises'
					and (isnull(c.BookCheckSailID, 0) = 0 or isnull(c.BookCheckSailID, 0) = 1 and isnull(p.SabreSailID, '') <> '')
			then 1
			else 0
		end												as 'BookableOnlineCSC'
	,	@EmbarkationDepartureTime						as 'EmbarkationDepartureTime'
	,	@DisembarkationArrivalTime						as 'DisembarkationArrivalTime'
	,	cp.advertised									as 'Advertised'
	,	@CampaignEndDate								as 'CampaignEndDate'
	,   i.EmbarkationPort_ID							as 'EmbarkationPort_ID'
	,	i.DisembarkationPort_ID							as 'DisembarkationPort_ID'
	from 	
		t_PR_Product 						as p
		left outer join t_CC_ExchangeRate 	as e 	on 	p.Cruiseline_ID = e.Cruiseline_ID and dbo.f_DisplayYearMonth(p.DepartureDate) = dbo.f_DisplayYearMonth(e.ExchangeDate)
		inner join t_CC_Ship 				as s 	on 	p.Ship_ID = s.Ship_ID	
		inner join t_CC_CruiseLineBrand		as c 	on 	p.CruiseLineBrand_ID = c.CruiseLineBrand_ID	
		left outer join v_CC_Itinerary 		as i with (NOEXPAND, index (PK_v_CC_Itinerary))	on 	p.Itinerary_ID = i.Itinerary_ID
		left outer join t_CC_Port			as ep	on	i.EmbarkationPort_ID = ep.Port_ID
		left outer join t_CC_Port			as dp	on	i.DisembarkationPort_ID = dp.Port_ID
		left outer join t_PR_GroupFIT		as fCAD	on	p.Product_ID = fCAD.FIT_CAD_Product_ID
		left outer join t_PR_GroupFIT		as fUSD	on	p.Product_ID = fUSD.FIT_USD_Product_ID
		left outer join 
			(
				Select 
					Product_ID, 
					Cast(MAX(list) as varchar(130)) as 'advertised' 
				from 
					(
						Select 
							x.Product_ID,	
							REPLACE('##' +(Select ',' + cp1.CampaignSubType 
											from t_CT_Campaign as cp1			
											inner join t_CT_CampaignDetail as cpd on cp1.Campaign_ID = cpd.Campaign_ID 
											where cpd.Product_ID = x.Product_ID 
											and cp1.CampaignSubType is not null 
											and cp1.CampaignSubType <> '' 
											and cp1.EndDate >= @Today 
											Group by cp1.CampaignSubType for xml  path('')), '##,', '') as 'list' 
						from t_CT_CampaignDetail as x) as v
						where v.Product_ID is not null 
						and v.list is not null
						Group by Product_ID) as cp on p.Product_ID = cp.Product_ID
	where	 
		p.Product_ID = @Product_ID
	
	end
GO
----------------------------------------------------------------------------------------------------------------------
/****** Object:  StoredProcedure [dbo].[p_PR_ProductPicture_Select]    Script Date: 08/08/2014 12:34:31 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[p_PR_ProductPicture_Select]
	@Product_ID 	int
,	@Web_ID			int				= 0
,	@CultureName 	varchar(10) 	= 'en-CA'
,	@RateType		varchar(30)		= ''
as
declare @NoValue 				int
declare	@AmenityOffer 			varchar(150)
declare	@Count 					int
declare	@EmbarkationPortPackage	bit
declare	@ReturnPortPackage		bit
declare @ExchangeRate			decimal(8, 4)
declare @ExchangeRateDate		smalldatetime
declare @EmbarkationDepartureTime	smalldatetime
declare @DisembarkationArrivalTime  smalldatetime

select	
	@ExchangeRate		= ExchangeRate
,	@ExchangeRateDate	= ExchangeRateDate
from
	t_PR_ExchangeRate
where
	ExchangeRate_ID = 1

set @NoValue		= -1

if @CultureName = ''
	set @CultureName = 'en-CA'

if @CultureName <>  'en-CA'
	select 	
		@AmenityOffer  = l.[Text]
	from 	
		t_CC_LanguageSource 				as ls
		inner join t_CC_LanguageTextUsage	as lu	on ls.LanguageSource_ID = lu.LanguageSource_ID
		inner join t_CC_LanguageText		as l 	on lu.Language_ID = l.Language_ID
	where 	
		ls.FieldName = 'AmenityOffer'
	and l.CultureName = @CultureName	

select 
	@Count = count(*) 
from 
	t_CS_LocalSpecial 
where 	
	Product_ID = @Product_ID 
and Web_ID = @Web_ID
and SpecialType = 'Local'	

select	
	@EmbarkationPortPackage = case when count(pp.PrePost_ID) > 0 then 1 else 0 end
from
	t_PR_ProductPicture				as pr
	inner join v_CC_Itinerary 		as i with (NOEXPAND, index (PK_v_CC_Itinerary))	on pr.Itinerary_ID = i.Itinerary_ID
	inner join t_PR_PrePost			as pp	on	i.EmbarkationPort_ID = pp.Port_ID
	inner join t_PR_PrePostDetail	as ppd	on	pp.PrePost_ID = ppd.PrePost_ID and DateAdd(Day, -pp.Duration, pr.DepartureDate) between ppd.StartDate and ppd.EndDate
where	
	pr.Product_ID = @Product_ID

select	
	@ReturnPortPackage = case when count(pp.PrePost_ID) > 0 then 1 else 0 end
from	
	t_PR_ProductPicture				as pr
	inner join v_CC_Itinerary		as i with (NOEXPAND, index (PK_v_CC_Itinerary))	on pr.Itinerary_ID = i.Itinerary_ID
	inner join t_PR_PrePost			as pp	on	i.DisembarkationPort_ID = pp.Port_ID
	inner join t_PR_PrePostDetail	as ppd	on	pp.PrePost_ID = ppd.PrePost_ID and DateAdd(Day, i.Duration, pr.DepartureDate) between ppd.StartDate and ppd.EndDate
where	
	pr.Product_ID = @Product_ID

select	
	@EmbarkationDepartureTime = max(case when RowNo = 1 then DepartureTime else null end)
,	@DisembarkationArrivalTime = max(case when RowNo = v.MaxRowNo then ArrivalTime else null end)
from	
	t_CC_Itinerary as i
	inner join t_CC_ItineraryTime as t on i.ItineraryTime_ID = t.ItineraryTime_ID
	inner join t_CC_ItineraryTimeDetail as d on t.ItineraryTime_ID = d.ItineraryTime_ID
	inner join (select max(RowNo) as 'MaxRowNo', ItineraryTime_ID from t_CC_ItineraryTimeDetail group by ItineraryTime_ID) as v on t.ItineraryTime_ID = v.ItineraryTime_ID
where
	Itinerary_ID = (
	select 
		Itinerary_ID
	from	
		t_PR_Product
	where
		Product_ID = @Product_ID)

select
-- from the t_PR_Product table
	p.Product_ID
,	p.Web_ID

,	p.Itinerary_ID
,	p.DepartureDate

,	p.CruiseLineBrand_ID
,	p.CruiseLine_ID
,	p.CruiseLineBrand
,	p.CruiseLine
,	p.CruiselineImage_ID
,	p.CruiselineImageType
,	p.CruiselineImageExtension

,	p.Ship_ID
,	p.Ship

,	p.CalculatedStatus
,	p.Status

,	p.ProductSource
,	p.ProductSourceDetail
,	p.GroupNumber
,	case when @CultureName <> 'en-CA' and isnull( p.GroupValue,'') <> '' 
		then isnull(@AmenityOffer, p.GroupValue)
		else p.GroupValue
	end 											as 'GroupValue'
,	p.GroupValueShort

,	p.Currency
,	p.ShowCAD
,	p.ShowUSD

,	p.GovernmentFees
,	p.GovernmentFeesCAD
,	p.GovernmentFeesUSD
,	case when p.GovernmentFeesUSD < 987654321 then p.GovernmentFeesUSD * @ExchangeRate else p.GovernmentFeesUSD end	as 'GovernmentFeesCADExch'

,	p.FuelSurcharge
,	p.FuelSurchargeCAD
,	p.FuelSurchargeUSD
,	case when p.FuelSurchargeUSD < 987654321 then p.FuelSurchargeUSD * @ExchangeRate else p.FuelSurchargeUSD end	as 'FuelSurchargeCADExch'

,	p.PortTaxes
,	p.PortTaxesCAD
,	p.PortTaxesUSD
,	case when p.PortTaxesUSD < 987654321 then p.PortTaxesUSD * @ExchangeRate else p.PortTaxesUSD end				as 'PortTaxesCADExch'
-- id Product Marked as Local Special
,	case when @Count > 0 
		then 1
		else 0
	end												as 'IsLocalSpecial'

-- sell sheet values
,	p.PriceInterior
,	p.PriceOceanView
,	p.PriceBalcony
,	p.PriceSuite

,	p.CategoryInteriorCode
,	p.CategoryOceanviewCode
,	p.CategoryBalconyCode
,	p.CategorySuiteCode

,	case when p.OurPrice <> 987654321 
		then p.OurPrice 
		else @NoValue 
	end 											as 'OurPrice'
,	case when p.OurPriceCAD <> 987654321 
		then p.OurPriceCAD
		else @NoValue 
	end 											as 'OurPriceCAD'
,	case when p.OurPriceUSD <> 987654321 
		then p.OurPriceUSD
		else @NoValue 
	end 											as 'OurPriceUSD'
,	case when p.OurPriceUSD <> 987654321 
		then ceiling(p.OurPriceUSD * @ExchangeRate)
		else @NoValue 
	end 											as 'OurPriceCADExch'

,	case when p.PriceInteriorCAD <> 987654321 
		then p.PriceInteriorCAD	
		else @NoValue 
	end 											as 'PriceInteriorCAD'
,	case when p.PriceInteriorUSD <> 987654321 
		then p.PriceInteriorUSD
		else @NoValue 
	end 											as 'PriceInteriorUSD'
,	case when p.PriceInteriorUSD <> 987654321 
		then ceiling(p.PriceInteriorUSD * @ExchangeRate)
		else @NoValue 
	end 											as 'PriceInteriorCADExch'

,	case when p.PriceOceanviewCAD <> 987654321 
		then p.PriceOceanviewCAD
		else @NoValue 
	end 											as 'PriceOceanviewCAD'
,	case when p.PriceOceanviewUSD <> 987654321 
		then p.PriceOceanviewUSD
		else @NoValue 
	end 											as 'PriceOceanviewUSD'
,	case when p.PriceOceanviewUSD <> 987654321 
		then ceiling(p.PriceOceanviewUSD * @ExchangeRate)
		else @NoValue 
	end 											as 'PriceOceanviewCADExch'

,	case when p.PriceBalconyCAD <> 987654321 
		then p.PriceBalconyCAD
		else @NoValue 
	end 											as 'PriceBalconyCAD'
,	case when p.PriceBalconyUSD <> 987654321 
		then p.PriceBalconyUSD
		else @NoValue 
	end 											as 'PriceBalconyUSD'
,	case when p.PriceBalconyUSD <> 987654321 
		then ceiling(p.PriceBalconyUSD * @ExchangeRate)
		else @NoValue 
	end 											as 'PriceBalconyCADExch'

,	case when p.PriceSuiteCAD <> 987654321 
		then p.PriceSuiteCAD
		else @NoValue 
	end 											as 'PriceSuiteCAD'
,	case when p.PriceSuiteUSD <> 987654321 
		then p.PriceSuiteUSD
		else @NoValue 	
	end 											as 'PriceSuiteUSD'
,	case when p.PriceSuiteUSD <> 987654321 
		then ceiling(p.PriceSuiteUSD * @ExchangeRate)
		else @NoValue 	
	end 											as 'PriceSuiteCADExch'

,	p.Restriction
,	p.RestrictionInside
,	p.RestrictionOceanview
,	p.RestrictionBalcony
,	p.RestrictionSuite

-- from the t_CC_Ship table
,	s.ShipClass_ID
,	s.ShipCode
,	s.SabreShipCode

-- from the t_CC_CruiseLine table
,	c.CruiseLineCode
,	c.SabreCode
,	case when @CultureName = 'en-CA' then 
		case when isnull(p.CruiseDescription, '') = '' then c.TranslatedDescription else isnull(p.CruiseDescription, '') end
	else c.TranslatedDescription  end as 'CruiseDescription'

-- from the t_CC_Itinerary table
,	case when isnull(ff.TranslatedFieldValue, '') = '' 
		then p.Destination 
		else ff.TranslatedFieldValue  
	end 											as 'Destination'
,	case when isnull(fs.TranslatedFieldValue, '') = '' 
		then p.Subdestination 
		else fs.TranslatedFieldValue 
	end 											as 'Subdestination'

----------------
,	e.TranslatedPortName							as 'EmbarkationPort'
,	d.TranslatedPortName							as 'ReturnPort'
,	@EmbarkationPortPackage							as 'EmbarkationPortPackage'
,	@ReturnPortPackage								as 'ReturnPortPackage'
,	p.Duration
,	p.Itinerary
,	p.Deposit

,	isnull(fc.GroupCAD_Product_ID, fu.GroupCAD_Product_ID) as 'GroupCAD_Product_ID'
,	isnull(fc.GroupUSD_Product_ID, fu.GroupUSD_Product_ID) as 'GroupUSD_Product_ID'

,	p.TotalAmenityPoints
,	c.TranslatedFuelDisclaimer							as 'Disclaimer'

,	p.SabreSailID
,	p.SabreDestinationCode
,	p.isCruiseTour
,	p.ActivityDate
,	p.CSCPromoCode
,	p.BookableOnlineCSC
,	p.BookableOnlineCD
,	isnull(p.BookUSOnly, 0)								as 'BookUSOnly'
,	p.OnlineSource
,	p.SabreAPIEnabled

,	@EmbarkationDepartureTime						as 'EmbarkationDepartureTime'
,	@DisembarkationArrivalTime						as 'DisembarkationArrivalTime'
,	p.PayPerPlacement
,	p.isShowFrenchInfoCruiseLine
,	p.DisableShipPhoto
,	p.isShowFrenchInfoShip
,	r.TotalReviews
,	r.AverageOverallRate
,	p.EmbarkationPort_ID							as 'EmbarkationPort_ID'
,	p.DisembarkationPort_ID							as 'DisembarkationPort_ID'
from 	
	t_PR_ProductPicture 													as p
	inner join t_CC_Ship 													as s 	on p.Ship_ID = s.Ship_ID	
	inner join f_CC_CruiselineBrand(@CultureName)							as c 	on p.CruiseLineBrand_ID = c.CruiseLineBrand_ID	
	inner join f_CC_Port(@CultureName)										as e 	on p.EmbarkationPort_ID = e.Port_ID
	inner join f_CC_Port(@CultureName)										as d 	on p.DisembarkationPort_ID = d.Port_ID
	left outer join f_CS_FieldValue(@CultureName, 'ProductDestination')		as ff 	on p.Destination = ff.FieldValue
	left outer join f_CS_FieldValue(@CultureName, 'ProductSubDestination')	as fs 	on p.SubDestination = fs.FieldValue
	left outer join t_PR_GroupFIT											as fc	on p.Product_ID = fc.FIT_CAD_Product_ID
	left outer join t_PR_GroupFIT											as fu	on p.Product_ID = fu.FIT_USD_Product_ID
	left outer join
	(Select Ship, TotalReviews, AverageOverallRate 
	from Report.dbo.t_PR_ReviewShipAverage where Culture = @CultureName)	as r	on CAST(p.Ship_ID as Varchar(50)) = r.Ship
where	 
	p.Product_ID = @Product_ID
GO