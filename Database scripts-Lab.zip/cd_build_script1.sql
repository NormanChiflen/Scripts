CREATE TABLE [dbo].[t_AD_PageView](
	[Page_ID] [int] NOT NULL,
	[Web_ID] [int] NOT NULL,
	[ViewDate] [smalldatetime] NOT NULL,
 CONSTRAINT [PK_t_AD_PageView] PRIMARY KEY CLUSTERED 
(
	[Page_ID] ASC,
	[Web_ID] ASC,
	[ViewDate] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
ALTER TABLE t_AD_Page ADD [PageNotes] [varchar](400) NULL
go
