USE [CruiseDesk]
GO
--#0--
Delete from CruiseDesk.dbo.t_AD_Project
--Select * from CruiseDesk.dbo.t_AD_Project
Where ProjectName like '%AgentTools%'

----------------------------------------------------------

USE [CruiseDesk]
GO
/****** Script for SelectTopNRows command from SSMS  ******/
--#1--

Delete from [CruiseDesk].[dbo].t_AD_Page
--Select * from [CruiseDesk].[dbo].t_AD_Page
Where Project_ID > 9

----------------------------------------------------------
USE [CruiseDesk]
GO
/****** Script for SelectTopNRows command from SSMS  ******/
--#2--

DECLARE @RolePageOld TABLE (Role_ID INT,Page_ID INT, PageName VARCHAR(150), Project_ID INT)
DECLARE @RolePageNew TABLE (Page_ID INT, PageName VARCHAR(150), Project_ID INT, Project_ID_OLD INT)

  INSERT INTO @RolePageOld
  (Role_ID
  , Page_ID
  ,PageName
  ,Project_ID
  )
SELECT  r1.[Role_ID]
      ,p1.[Page_ID]
     ,p1.PageName      
      ,p1.Project_ID
  FROM [CruiseDesk].[dbo].[t_AD_RolePage] as r1
  inner join [CruiseDesk].[dbo].[t_AD_Page] as p1 on p1.Page_ID = r1.Page_ID
 where p1.Project_ID <= 9  


 INSERT INTO @RolePageNew
  ( Page_ID
  ,PageName
  ,Project_ID
  ,Project_ID_OLD
  )
SELECT 
      p2.[Page_ID]      
      ,p2.PageName
      ,p2.Project_ID
      , case 
		when Project_ID = 13 then 1
		when Project_ID = 16 then 2
		when Project_ID = 11 then 3 
		when Project_ID = 17 then 4
		when Project_ID = 15 then 5
		when Project_ID = 12 then 6 
		when Project_ID = 10 then 7 
		when Project_ID = 14 then 8 
		when Project_ID = 18 then 9 
			end as 'Project_ID_OLD'
  FROM [CruiseDesk].[dbo].t_AD_Page as p2
 where p2.Project_ID > 9


 Delete [CruiseDesk].[dbo].[t_AD_RolePage]
 from [CruiseDesk].[dbo].[t_AD_RolePage] as rp
 --Select * from [CruiseDesk].[dbo].[t_AD_RolePage] as rp
 inner join  @RolePageOld as rpo on rpo.Role_ID = rp.Role_ID
	  inner join @RolePageNew as rpn on rpn.PageName = rpo.PageName
									and rpn.Project_ID_OLD = rpo.Project_ID
Where rp.Role_ID = rpo.Role_ID
and rp.Page_ID = rpn.Page_ID									
 
 ------------------------------------------------------------

 USE [CruiseDesk]
GO
/****** Script for SelectTopNRows command from SSMS  ******/
--#3--
 
  Delete [CruiseDesk].[dbo].t_AD_RoleProject
  where Project_ID > 9

 -----------------------------------------------------------

  DECLARE @SectionOld TABLE (Section_ID INT,Page_ID INT, SectionName VARCHAR(150), PageName varchar(150), Project_ID INT, 

DateDeleted Date,SectionIDNew int)
DECLARE @SectionNew TABLE (Page_ID INT, PageName varchar(150), Project_ID INT, Project_ID_OLD INT)

Declare @SectionID int
select @SectionID = MAX(Section_ID) FROM [CruiseDesk].[dbo].[t_AD_Section]
  
  INSERT INTO @SectionOld
  (Section_ID
  , Page_ID
  ,SectionName
  ,PageName
  ,Project_ID
  ,DateDeleted
  ,SectionIDNew
  )  
SELECT  s1.[Section_ID]
            ,p1.[Page_ID]
            ,s1.SectionName         
            ,p1.PageName      
            ,p1.Project_ID
            ,s1.DateDeleted
            ,(ROW_NUMBER() over(Order by (Select Null))+@SectionID) as 'SectionIDNew'
  FROM [CruiseDesk].[dbo].[t_AD_Section] as s1
  inner join [CruiseDesk].[dbo].[t_AD_Page] as p1 on p1.Page_ID = s1.Page_ID
where p1.Project_ID <= 9  
 

INSERT INTO @SectionNew
  ( Page_ID
  ,PageName
  ,Project_ID
  ,Project_ID_OLD
  )   
SELECT  p1.[Page_ID]
            ,p1.PageName      
            ,p1.Project_ID
            , case 
            when Project_ID = 13 then 1
            when Project_ID = 16 then 2
            when Project_ID = 11 then 3 
            when Project_ID = 17 then 4
            when Project_ID = 15 then 5
            when Project_ID = 12 then 6 
            when Project_ID = 10 then 7 
            when Project_ID = 14 then 8 
            when Project_ID = 18 then 9 
                  end as 'Project_ID_OLD'
  FROM [CruiseDesk].[dbo].t_AD_Page as p1  
 where p1.Project_ID > 9  
 
delete from [CruiseDesk].[dbo].[t_AD_Section]
where section_ID in(
select
      so.SectionIDNew
      
from
        @SectionOld as so
        inner join @SectionNew as sn on sn.PageName = so.PageName
                                                      and sn.Project_ID_OLD = so.Project_ID
)

------------------------------------------------------------------------------------------------------

USE [CruiseDesk]
GO
/****** Script for SelectTopNRows command from SSMS  ******/
--5--


DECLARE @RoleSectionOld TABLE (Section_ID INT, Role_ID int, Page_ID INT, SectionName VARCHAR(150), PageName varchar(150), 

Project_ID INT)
DECLARE @RoleSectionNew TABLE (Section_ID INT, Page_ID INT, SectionName VARCHAR(150), PageName varchar(150), Project_ID INT, 

Project_ID_OLD INT)
  
  INSERT INTO @RoleSectionOld
  (Section_ID
  ,Role_ID
  , Page_ID
  ,SectionName
  ,PageName
  ,Project_ID
  )  
SELECT   s1.[Section_ID]
            ,rs.Role_ID
            ,p1.[Page_ID]
            ,s1.SectionName         
            ,p1.PageName      
            ,p1.Project_ID
  FROM [CruiseDesk].[dbo].[t_AD_Section] as s1
  inner join [CruiseDesk].[dbo].[t_AD_RoleSection] as rs on rs.Section_ID= s1.Section_ID
  inner join [CruiseDesk].[dbo].[t_AD_Page] as p1 on p1.Page_ID = s1.Page_ID
where p1.Project_ID <= 9   
 
 
  INSERT INTO @RoleSectionNew
  (Section_ID
  , Page_ID
  ,SectionName
  ,PageName
  ,Project_ID
  ,Project_ID_OLD
  )   
 SELECT   s1.[Section_ID]
            ,p1.[Page_ID]
            ,s1.SectionName         
            ,p1.PageName      
            ,p1.Project_ID
            , case 
            when Project_ID = 13 then 1
            when Project_ID = 16 then 2
            when Project_ID = 11 then 3 
            when Project_ID = 17 then 4
            when Project_ID = 15 then 5
            when Project_ID = 12 then 6 
            when Project_ID = 10 then 7 
            when Project_ID = 14 then 8 
            when Project_ID = 18 then 9 
                  end as 'Project_ID_OLD'
FROM [CruiseDesk].[dbo].[t_AD_Page] as p1
inner join [CruiseDesk].[dbo].[t_AD_Section] as s1 on s1.Page_ID = p1.Page_ID
where p1.Project_ID > 9   
 
 delete [CruiseDesk].[dbo].[t_AD_RoleSection]
 from [CruiseDesk].[dbo].[t_AD_RoleSection] as rs
--select * from [CruiseDesk].[dbo].[t_AD_RoleSection] as rs 
 inner join @RoleSectionOld as rso on rs.role_ID = rso.role_ID
        inner join @RoleSectionNew as rsn on rsn.PageName = rso.PageName
                                                      and rsn.Project_ID_OLD = rso.Project_ID
                                                      and rsn.SectionName = rso.SectionName
                                                      
                                                      
where rs.Role_ID = rso.Role_ID
and rs.section_ID = rsn.Section_ID
                                                     
-------------------------------------------------------------------------------------------------------------

USE [CruiseDesk]
GO
/****** Script for SelectTopNRows command from SSMS  ******/
--#6--
  Delete [CruiseDesk].[dbo].t_AD_WebProject
  Where Project_ID > 9

-------------------------------------------------------------------------------------------------------------

USE [CruiseDesk]
GO
/****** Script for SelectTopNRows command from SSMS  ******/
--#7--
    
DECLARE @WebSectionOld TABLE (Web_ID INT, Section_ID int, Page_ID INT, SectionName VARCHAR(150), PageName varchar(150), Project_ID INT)
DECLARE @WebSectionNew TABLE (Section_ID int, Page_ID INT, SectionName VARCHAR(150), PageName varchar(150), Project_ID INT, Project_ID_OLD INT)
  
  INSERT INTO @WebSectionOld
  (Web_ID
  ,Section_ID
  ,Page_ID
  ,SectionName
  ,PageName
  ,Project_ID
  )  
SELECT   ws1.[Web_ID]
		,s1.Section_ID
		,p1.[Page_ID]
		,s1.SectionName	      
		,p1.PageName      
		,p1.Project_ID
  FROM [CruiseDesk].[dbo].[t_AD_WebSection] as ws1
  inner join [CruiseDesk].[dbo].[t_AD_Section] as s1 on s1.Section_ID= ws1.Section_ID
  inner join [CruiseDesk].[dbo].[t_AD_Page] as p1 on p1.Page_ID = s1.Page_ID
 where p1.Project_ID <= 9   
 
 
  INSERT INTO @WebSectionNew
  (Section_ID
  ,Page_ID
  ,SectionName
  ,PageName
  ,Project_ID
  ,Project_ID_OLD
  )   
  SELECT  
		s1.Section_ID
		,p1.[Page_ID]
		,s1.SectionName	      
		,p1.PageName      
		,p1.Project_ID
		, case 
		when Project_ID = 13 then 1
		when Project_ID = 16 then 2
		when Project_ID = 11 then 3 
		when Project_ID = 17 then 4
		when Project_ID = 15 then 5
		when Project_ID = 12 then 6 
		when Project_ID = 10 then 7 
		when Project_ID = 14 then 8 
		when Project_ID = 18 then 9 
			end as 'Project_ID_OLD'
  FROM [CruiseDesk].[dbo].[t_AD_Page] as p1 
  inner join [CruiseDesk].[dbo].[t_AD_Section] as s1 on s1.Page_ID= p1.Page_ID
 where p1.Project_ID > 9  
 
 Delete [CruiseDesk].[dbo].[t_AD_WebSection]
 from [CruiseDesk].[dbo].[t_AD_WebSection] as ws
 
 inner join @WebSectionOld as wso on wso.Web_ID = ws.Web_ID
	  inner join @WebSectionNew as wsn on wsn.PageName = wso.PageName
									and wsn.Project_ID_OLD = wso.Project_ID
									and wsn.SectionName = wso.SectionName
where ws.Web_ID = wso.Web_ID
and ws.Section_ID = wsn.Section_ID									
 
