--#0--
Insert INTO CruiseDesk.dbo.t_AD_Project
  (Project_ID, ProjectName, DateDeleted)
VALUES  (10, 'AgentTools', NULL)

 Insert INTO CruiseDesk.dbo.t_AD_Project
  (Project_ID, ProjectName, DateDeleted)
VALUES  (11, 'AgentTools_Administration', NULL)

 Insert INTO CruiseDesk.dbo.t_AD_Project
  (Project_ID, ProjectName, DateDeleted)
VALUES  (12, 'AgentTools_Api', NULL)

 Insert INTO CruiseDesk.dbo.t_AD_Project
  (Project_ID, ProjectName, DateDeleted)
VALUES  (13, 'AgentTools_Content', NULL)

 Insert INTO CruiseDesk.dbo.t_AD_Project
  (Project_ID, ProjectName, DateDeleted)
VALUES  (14, 'AgentTools_CTO', NULL)

 Insert INTO CruiseDesk.dbo.t_AD_Project
  (Project_ID, ProjectName, DateDeleted)
VALUES  (15, 'AgentTools_Product', NULL)

 Insert INTO CruiseDesk.dbo.t_AD_Project
  (Project_ID, ProjectName, DateDeleted)
VALUES  (16, 'AgentTools_Purser', NULL)

 Insert INTO CruiseDesk.dbo.t_AD_Project
  (Project_ID, ProjectName, DateDeleted)
VALUES  (17, 'AgentTools_Report', NULL)

 Insert INTO CruiseDesk.dbo.t_AD_Project
  (Project_ID, ProjectName, DateDeleted)
VALUES  (18, 'AgentTools_SevenSeas', NULL)

--#1--

Declare @pageID int
select @pageID = MAX(Page_ID) from t_AD_Page
  
  INSERT INTO [CruiseDesk].[dbo].t_AD_Page
  (PageNotes
  , MenuName
  , DateDeleted
  , PageName
  , Project_ID
	, Page_ID
  )
SELECT     
	PageNotes
	, MenuName
	, DateDeleted
	, PageName
	, case 
		when Project_ID = 1 then 13 
		when Project_ID = 2 then 16 
		when Project_ID = 3 then 11 
		when Project_ID = 4 then 17 
		when Project_ID = 5 then 15 
		when Project_ID = 6 then 12 
		when Project_ID = 7 then 10 
		when Project_ID = 8 then 14 
		when Project_ID = 9 then 18 
			end as 'Project_ID'
	,(ROW_NUMBER() over(Order by (Select Null))+@pageID)  as 'Page_ID'
FROM         
	t_AD_Page AS t_AD_Page_1
Where
	Project_ID <=9

---------------------------------------------------------------------------
/****** Script for SelectTopNRows command from SSMS  ******/
--#2--

DECLARE @RolePageOld TABLE (Role_ID INT,Page_ID INT, PageName VARCHAR(150), Project_ID INT)
DECLARE @RolePageNew TABLE (Page_ID INT, PageName VARCHAR(150), Project_ID INT, Project_ID_OLD INT)

  INSERT INTO @RolePageOld
  (Role_ID
  , Page_ID
  ,PageName
  ,Project_ID
  )
SELECT  r1.[Role_ID]
      ,p1.[Page_ID]
     ,p1.PageName      
      ,p1.Project_ID
  FROM [CruiseDesk].[dbo].[t_AD_RolePage] as r1
  inner join [CruiseDesk].[dbo].[t_AD_Page] as p1 on p1.Page_ID = r1.Page_ID
 where p1.Project_ID <= 9  


 INSERT INTO @RolePageNew
  ( Page_ID
  ,PageName
  ,Project_ID
  ,Project_ID_OLD
  )
SELECT 
      p2.[Page_ID]      
      ,p2.PageName
      ,p2.Project_ID
      , case 
		when Project_ID = 13 then 1
		when Project_ID = 16 then 2
		when Project_ID = 11 then 3 
		when Project_ID = 17 then 4
		when Project_ID = 15 then 5
		when Project_ID = 12 then 6 
		when Project_ID = 10 then 7 
		when Project_ID = 14 then 8 
		when Project_ID = 18 then 9 
			end as 'Project_ID_OLD'
  FROM [CruiseDesk].[dbo].t_AD_Page as p2
 where p2.Project_ID > 9


  INSERT INTO [CruiseDesk].[dbo].[t_AD_RolePage]
  (Role_ID
  , Page_ID
  )
select 
	 rpo.Role_ID
	 ,rpn.Page_ID
	 --,*
from
	  @RolePageOld as rpo
	  inner join @RolePageNew as rpn on rpn.PageName = rpo.PageName
									and rpn.Project_ID_OLD = rpo.Project_ID

-------------------------------------------------------------------------------------------------------
/****** Script for SelectTopNRows command from SSMS  ******/
--#3--
 
  
    INSERT INTO [CruiseDesk].[dbo].t_AD_RoleProject
  (Role_ID
  , Project_ID
  )
SELECT     
	Role_ID
  , case 
		when Project_ID = 1 then 13 
		when Project_ID = 2 then 16 
		when Project_ID = 3 then 11 
		when Project_ID = 4 then 17 
		when Project_ID = 5 then 15 
		when Project_ID = 6 then 12 
		when Project_ID = 7 then 10 
		when Project_ID = 8 then 14 
		when Project_ID = 9 then 18 
			end as 'Project_ID'
FROM         
	[CruiseDesk].[dbo].t_AD_RoleProject AS t_AD_RoleProject_1

------------------------------------------------------------------
/****** Script for SelectTopNRows command from SSMS  ******/
--#4--

DECLARE @SectionOld TABLE (Section_ID INT,Page_ID INT, SectionName VARCHAR(150), PageName varchar(150), Project_ID INT, DateDeleted Date,SectionIDNew int)
DECLARE @SectionNew TABLE (Page_ID INT, PageName varchar(150), Project_ID INT, Project_ID_OLD INT)

Declare @SectionID int
select @SectionID = MAX(Section_ID) FROM [CruiseDesk].[dbo].[t_AD_Section]
  
  INSERT INTO @SectionOld
  (Section_ID
  , Page_ID
  ,SectionName
  ,PageName
  ,Project_ID
  ,DateDeleted
  ,SectionIDNew
  )  
SELECT  s1.[Section_ID]
		,p1.[Page_ID]
		,s1.SectionName	      
		,p1.PageName      
		,p1.Project_ID
		,s1.DateDeleted
		,(ROW_NUMBER() over(Order by (Select Null))+@SectionID) as 'SectionIDNew'
  FROM [CruiseDesk].[dbo].[t_AD_Section] as s1
  inner join [CruiseDesk].[dbo].[t_AD_Page] as p1 on p1.Page_ID = s1.Page_ID
 where p1.Project_ID <= 9  
 

 INSERT INTO @SectionNew
  ( Page_ID
  ,PageName
  ,Project_ID
  ,Project_ID_OLD
  )   
SELECT  p1.[Page_ID]
		,p1.PageName      
		,p1.Project_ID
		, case 
		when Project_ID = 13 then 1
		when Project_ID = 16 then 2
		when Project_ID = 11 then 3 
		when Project_ID = 17 then 4
		when Project_ID = 15 then 5
		when Project_ID = 12 then 6 
		when Project_ID = 10 then 7 
		when Project_ID = 14 then 8 
		when Project_ID = 18 then 9 
			end as 'Project_ID_OLD'
  FROM [CruiseDesk].[dbo].t_AD_Page as p1  
 where p1.Project_ID > 9  
 

  INSERT INTO [CruiseDesk].[dbo].[t_AD_Section]
  (Section_ID
  ,Page_ID
  ,SectionName
  ,DateDeleted
  )
select
	 so.SectionIDNew
	 ,sn.Page_ID
	 ,so.SectionName
	 ,so.DateDeleted
from
	  @SectionOld as so
	  inner join @SectionNew as sn on sn.PageName = so.PageName
									and sn.Project_ID_OLD = so.Project_ID

------------------------------------------------------------------------------------------
/****** Script for SelectTopNRows command from SSMS  ******/
--#5--

DECLARE @RoleSectionOld TABLE (Section_ID INT, Role_ID int, Page_ID INT, SectionName VARCHAR(150), PageName varchar(150), Project_ID INT)
DECLARE @RoleSectionNew TABLE (Section_ID INT, Page_ID INT, SectionName VARCHAR(150), PageName varchar(150), Project_ID INT, Project_ID_OLD INT)
  
  INSERT INTO @RoleSectionOld
  (Section_ID
  ,Role_ID
  , Page_ID
  ,SectionName
  ,PageName
  ,Project_ID
  )  
SELECT   s1.[Section_ID]
		,rs.Role_ID
		,p1.[Page_ID]
		,s1.SectionName	      
		,p1.PageName      
		,p1.Project_ID
  FROM [CruiseDesk].[dbo].[t_AD_Section] as s1
  inner join [CruiseDesk].[dbo].[t_AD_RoleSection] as rs on rs.Section_ID= s1.Section_ID
  inner join [CruiseDesk].[dbo].[t_AD_Page] as p1 on p1.Page_ID = s1.Page_ID
 where p1.Project_ID <= 9   
 
 
  INSERT INTO @RoleSectionNew
  (Section_ID
  , Page_ID
  ,SectionName
  ,PageName
  ,Project_ID
  ,Project_ID_OLD
  )   
 SELECT   s1.[Section_ID]
		,p1.[Page_ID]
		,s1.SectionName	      
		,p1.PageName      
		,p1.Project_ID
		, case 
		when Project_ID = 13 then 1
		when Project_ID = 16 then 2
		when Project_ID = 11 then 3 
		when Project_ID = 17 then 4
		when Project_ID = 15 then 5
		when Project_ID = 12 then 6 
		when Project_ID = 10 then 7 
		when Project_ID = 14 then 8 
		when Project_ID = 18 then 9 
			end as 'Project_ID_OLD'
FROM [CruiseDesk].[dbo].[t_AD_Page] as p1
inner join [CruiseDesk].[dbo].[t_AD_Section] as s1 on s1.Page_ID = p1.Page_ID
 where p1.Project_ID > 9   
 
  INSERT INTO [CruiseDesk].[dbo].[t_AD_RoleSection]
  (Role_ID
	,Section_ID
  )
select 
	 rso.Role_ID
	 ,rsn.Section_ID
	 --,*
from
	  @RoleSectionOld as rso
	  inner join @RoleSectionNew as rsn on rsn.PageName = rso.PageName
									and rsn.Project_ID_OLD = rso.Project_ID
									and rsn.SectionName = rso.SectionName

---------------------------------------------------------------------------------------------------------------
/****** Script for SelectTopNRows command from SSMS  ******/
--#6--
  
  INSERT INTO [CruiseDesk].[dbo].t_AD_WebProject
  (Web_ID
  , Project_ID
  )
SELECT     
	Web_ID
  , case 
		when Project_ID = 1 then 13 
		when Project_ID = 2 then 16 
		when Project_ID = 3 then 11 
		when Project_ID = 4 then 17 
		when Project_ID = 5 then 15 
		when Project_ID = 6 then 12 
		when Project_ID = 7 then 10 
		when Project_ID = 8 then 14 
		when Project_ID = 9 then 18 
			end as 'Project_ID'
FROM         
	[CruiseDesk].[dbo].t_AD_WebProject AS t_AD_WebProject_1

---------------------------------------------------------------------------------------------------------
/****** Script for SelectTopNRows command from SSMS  ******/
--#7--
    
DECLARE @WebSectionOld TABLE (Web_ID INT, Section_ID int, Page_ID INT, SectionName VARCHAR(150), PageName varchar(150), Project_ID INT)
DECLARE @WebSectionNew TABLE (Section_ID int, Page_ID INT, SectionName VARCHAR(150), PageName varchar(150), Project_ID INT, Project_ID_OLD INT)
  
  INSERT INTO @WebSectionOld
  (Web_ID
  ,Section_ID
  ,Page_ID
  ,SectionName
  ,PageName
  ,Project_ID
  )  
SELECT   ws1.[Web_ID]
		,s1.Section_ID
		,p1.[Page_ID]
		,s1.SectionName	      
		,p1.PageName      
		,p1.Project_ID
  FROM [CruiseDesk].[dbo].[t_AD_WebSection] as ws1
  inner join [CruiseDesk].[dbo].[t_AD_Section] as s1 on s1.Section_ID= ws1.Section_ID
  inner join [CruiseDesk].[dbo].[t_AD_Page] as p1 on p1.Page_ID = s1.Page_ID
 where p1.Project_ID <= 9   
 
 
  INSERT INTO @WebSectionNew
  (Section_ID
  ,Page_ID
  ,SectionName
  ,PageName
  ,Project_ID
  ,Project_ID_OLD
  )   
  SELECT  
		s1.Section_ID
		,p1.[Page_ID]
		,s1.SectionName	      
		,p1.PageName      
		,p1.Project_ID
		, case 
		when Project_ID = 13 then 1
		when Project_ID = 16 then 2
		when Project_ID = 11 then 3 
		when Project_ID = 17 then 4
		when Project_ID = 15 then 5
		when Project_ID = 12 then 6 
		when Project_ID = 10 then 7 
		when Project_ID = 14 then 8 
		when Project_ID = 18 then 9 
			end as 'Project_ID_OLD'
  FROM [CruiseDesk].[dbo].[t_AD_Page] as p1 
  inner join [CruiseDesk].[dbo].[t_AD_Section] as s1 on s1.Page_ID= p1.Page_ID
 where p1.Project_ID > 9  
 
  INSERT INTO [CruiseDesk].[dbo].[t_AD_WebSection]
  (Web_ID
	,Section_ID
  )
select
	 wso.Web_ID
	 ,wsn.Section_ID
	 --,*
from
	  @WebSectionOld as wso
	  inner join @WebSectionNew as wsn on wsn.PageName = wso.PageName
									and wsn.Project_ID_OLD = wso.Project_ID
									and wsn.SectionName = wso.SectionName


