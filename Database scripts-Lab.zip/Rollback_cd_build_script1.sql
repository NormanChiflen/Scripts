drop table [dbo].[t_AD_PageView]
go
ALTER TABLE [dbo].[t_AD_Page] DROP COLUMN 
	[PageNotes]
GO
