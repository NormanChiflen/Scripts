---------------------------------------------------------------------------------------------------------------------------
/****** Object:  StoredProcedure [dbo].[p_AD_Page_Update_PageNotes]    Script Date: 06/27/2014 11:48:00 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[p_AD_Page_Update_PageNotes] 
	@Page_ID 	int
,	@PageNotes 	varchar(400)

AS

update	
	t_AD_Page
set
	PageNotes = @PageNotes
where
	Page_ID = @Page_ID
  
--------------------------------------------------------------------------------------
  update [CruiseDesk].[dbo].[t_AD_Center]
                set Country='US'
                where Center_ID=15329
--------------------------------------------------------------------------------------
go
grant execute on p_AD_Page_Update_PageNotes to ccuser
go


