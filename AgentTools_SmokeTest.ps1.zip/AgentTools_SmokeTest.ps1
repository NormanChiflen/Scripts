$login = "http://chelwbtestr73/logi.aspx?ReturnUrl=%2f"
$username = "testaccount@expedia.com"
$password = "T3st@cc0un"
$stringSearched = "ENTER CRUISE AGENT TOOLS"

$ie = New-Object -com InternetExplorer.Application 
$ie.visible=$false
$ie.navigate($login) 
while($ie.ReadyState -ne 4) {start-sleep -m 100} 
$ie.document.body | Out-File -FilePath c:\scripts\login.txt 
$innerText = $ie.document.body.innertext

if ($innerText.Contains($stringSearched)) {
  $testStatus = "SUCCEEDED"
  $returnValue = 0
}
else {
  $testStatus = "FAILED"
  $returnValue = 1
}


"

Smoke Test $testStatus !!!

Script Parameters:-
 - String Searched: $stringSearched'
 - Login Page: $login
 - Username: $username

Return value in the body of the navigated page was:

-------------------------------
$innerText
-------------------------------

" 
return $returnValue